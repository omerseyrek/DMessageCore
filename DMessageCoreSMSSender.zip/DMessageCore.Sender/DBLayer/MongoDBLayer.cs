using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using DMessageCoreCommon.Model;
using DMessageCoreSender.DBLayer;
using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using MongoDB.Driver;

namespace DMessageCoreCommon.DBLayer {
    public class MongoDBLayer<T> : IDBLayer<T> where T : EntityBase, new () {

        readonly IMongoDatabase db;
        public MongoDBLayer (IConfiguration conf) {

            EntityBase item = GetEntityInstence ();
            string collectionName = item.GetCollectionName ();

            var conenctionString = conf.GetValue<string> ("Data:MongoConnection");
            var client = new MongoClient (conenctionString);
            db = client.GetDatabase (collectionName);
        }

        public void delete (Guid Id) {
            EntityBase item = GetEntityInstence ();
            var collection = db.GetCollection<T> (item.GetSubCollectionName ());
            var filter = Builders<T>.Filter.Eq ("Id", Id);
            collection.DeleteOne (filter);
        }

        public void delete (T record) {
            var collection = db.GetCollection<T> (record.GetSubCollectionName ());
            var filter = Builders<T>.Filter.Eq ("Id", record.Id);
            collection.DeleteOne (filter);
        }


        public List<T> Filter (Expression<Func<T, bool>> filter, Expression<Func<T, object>> order, bool IsDescending = false) {
            EntityBase item = GetEntityInstence ();
            var collection = db.GetCollection<T> (item.GetSubCollectionName ());
              if (order != null) {
                return IsDescending ? collection.Find (filter).SortByDescending (order).ToList () : collection.Find (filter).SortBy (order).ToList ();
            } else {
               return collection.Find (filter).ToList ();
            }
        }
        public T FindOne (Expression<Func<T, bool>> filter, Expression<Func<T, object>> order, bool IsDescending) {
            EntityBase item = GetEntityInstence ();
            var collection = db.GetCollection<T> (item.GetSubCollectionName ());
            if (order != null) {
                return IsDescending ? collection.Find (filter).SortByDescending (order).FirstOrDefault () : collection.Find (filter) .SortBy (order) .FirstOrDefault();
                
            } else {
                return collection.Find(filter).FirstOrDefault();
            }
        }

        public List<T> getAll () {
            EntityBase item = GetEntityInstence ();
            var collection = db.GetCollection<T> (item.GetSubCollectionName ());
            return collection.Find (new BsonDocument ()).ToList ();
        }

        public T getByID (Guid Id) {
            EntityBase item = GetEntityInstence ();
            var collection = db.GetCollection<T> (item.GetSubCollectionName ());
            var filter = Builders<T>.Filter.Eq ("Id", Id);
            var filterresult = collection.Find (filter);
            if (filterresult.Any ()) {
                return collection.Find (filter).First ();
            }
            return default (T);
        }

        public void save (T record) {
            var collection = db.GetCollection<T> (record.GetSubCollectionName ());

            if ( (record?.Id ?? default) == default) {
                collection.InsertOne (record);
            } else {
                var filter = Builders<T>.Filter.Eq ("Id", record.Id);
                var opt = new ReplaceOptions () { IsUpsert = true };
                ReplaceOneResult replaceOneResult = collection.ReplaceOne (filter, record, opt);

                if (replaceOneResult.ModifiedCount == 0) {
                    collection.InsertOne (record);
                }
            }
        }

        private EntityBase GetEntityInstence () {
            T t = new T ();
            EntityBase item = t;
            return item;
        }

    }
}