using DMessageCoreCommon.Model;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace DMessageCoreSender.DBLayer
{
    public interface IDBLayer<T> where T : EntityBase, new()
    {
        void save(T record);

        List<T> getAll();

        T getByID(Guid Id);

        void delete(Guid Id);

        void delete(T record);

        List<T> Filter(Expression<Func<T, bool>> filter, Expression<Func<T, object>> order, bool IsDescending = false);

        T FindOne(Expression<Func<T, bool>> filter, Expression<Func<T, object>> order, bool IsDescending = false);

    }
}

