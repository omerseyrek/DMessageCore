using System;
using MongoDB.Bson.Serialization.Attributes;


namespace DMessageCoreCommon.Model
{
    public class EntityBase
    {
        [BsonId]
         public Guid Id { get; set; } 

        public virtual string GetCollectionName() { return "DMessageAccounts";  }

        public virtual string GetSubCollectionName() { return ""; }
    }
}