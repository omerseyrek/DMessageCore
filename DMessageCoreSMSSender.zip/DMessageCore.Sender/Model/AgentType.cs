namespace DMessageCoreCommon.Model
{
    public enum AgentType
    {
        Turkcell = 1,
        EuroMessage = 2,
        Codec = 3
    }
}