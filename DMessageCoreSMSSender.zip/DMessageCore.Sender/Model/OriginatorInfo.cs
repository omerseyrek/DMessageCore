namespace DMessageCoreCommon.Model
{
    public class OriginatorInfo
    {
        public bool IsDefault { get; set; } 

        public string Originator { get; set; }
    }
}