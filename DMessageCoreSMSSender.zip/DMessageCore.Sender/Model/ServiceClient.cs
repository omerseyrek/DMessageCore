using System;
using System.Collections.Generic;


namespace DMessageCoreCommon.Model
{
    public class ServiceClient : EntityBase
    {

        public String BussinesName { get; set; }

        public string ApplicationName { get; set; }

        public string BillingDepartment { get; set; }

        public List<string> ResponsiblePeople { get; set; } 

        public List<string> ResponsbleEmails { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public bool PushDelete { get; set; }  //push the delete command to rabbitt mq parameter collection

        public List<SMSProviderParameters> SMSProviders { get; set; }

        public List<EMailProviderParameters> EMailProviders { get; set; }

        public List<MobileApp> MobileApps { get; set; }

        public override string GetCollectionName()
        {
            return "DMessageAccounts";
        }

        public override string GetSubCollectionName()
        {
            return "Receivers";
        }
    }
}