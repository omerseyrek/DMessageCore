using System;

namespace DMessageReceiver.ServiceLayer 
{
    public class NotificationRequest {
        public int CustomerType { get; set; }
        public string CustomerName { get; set; }

        public AppType AppType { get; set; }

        public string ClientId { get; set; }

        public Guid ApplicationId { get; set; }

        public string Subject { get; set; }

        public string Message { get; set; }

        public string Json { get; set; }
    }

    public enum AppType
    {
        Android = 1,
        IOS = 2
    }
}