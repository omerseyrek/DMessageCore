namespace DMessageCoreCommon.Model
{
    public class PushParameters
    {
        public AgentType AgentType { get; set; }

        public string  AppName { get; set; }

        public string AgentPassword { get; set; }

        public string  RegisterUrl { get; set; }


        public string  PostUrl { get; set; }  

        
        public string  FromName { get; set; }  

        
        public string  FromAdres { get; set; }  

        
        public string  ReplayAdres { get; set; }  

        
    }
}