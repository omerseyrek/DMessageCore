﻿using System;

namespace DMessageCoreCommon.Model
{
    public interface ITokenField
    {
        public string AgentNameProxy { get; set; }

        public string AgentPasswordProxy { get; set; }

        public string TokenProxy { get; set; }

        public AgentType AgentTypeProxy { get; set; }

        public Guid BussinesClientIdProxy { get; set; }
    }

}