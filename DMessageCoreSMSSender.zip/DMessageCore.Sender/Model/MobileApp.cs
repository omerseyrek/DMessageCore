﻿using System;

namespace DMessageCoreCommon.Model
{
    public class MobileApp
    {
        public Guid ApplicationID { get; set; }

        public string ApplicationName { get; set; }

        public AppleMobileAppDetail IOS { get; set; }

        public AndroidMobileAppDetail Android { get; set; }

        public bool IsDefault { get; set; }


    }
}