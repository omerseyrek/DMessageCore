namespace DMessageCoreCommon.Model
{
    public enum ApnsServerVersion
    {
        Sandbox = 1,
        Production = 2
    }
}