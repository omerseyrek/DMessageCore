namespace DMessageCoreCommon.Model
{
    public enum OperatorType
    {
        Android = 1,
        Apple = 2
    }
}