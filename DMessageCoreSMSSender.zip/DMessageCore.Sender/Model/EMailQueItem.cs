﻿using System;
using System.Collections.Generic;
using DMessageReceiver.Model;

namespace DMessageCoreCommon.Model
{
    public class EMailQueItem : EntityBase, ITokenField
    {
        public Guid BussinesClientId { get; set; }

        public string BussinesClientName { get; set; }

        public bool WithType { get; set; }

        public EMailProviderParameters EMailProvider { get; set; }

        public EMailRequest EMailRequest { get; set; }

        public List<TrialResult> TrialResults { get; set; }

        public string AgentNameProxy { get => EMailProvider.AgentUserName; set => EMailProvider.AgentUserName = value; }

        public string AgentPasswordProxy { get => EMailProvider.AgentPassword; set => EMailProvider.AgentPassword = value; }

        public string TokenProxy { get => EMailProvider.Token; set => EMailProvider.Token = value; }

        public AgentType AgentTypeProxy { get => EMailProvider.AgentType; set => EMailProvider.AgentType = value; }

        public Guid BussinesClientIdProxy { get => BussinesClientId; set => BussinesClientId = value; }

        public override string GetSubCollectionName()
        {
            return "EmailQue";
        }
    }


}