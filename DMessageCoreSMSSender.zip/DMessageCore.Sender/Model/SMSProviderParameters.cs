using System.Collections.Generic;


namespace DMessageCoreCommon.Model
{
    public class SMSProviderParameters
    {
        public AgentType AgentType { get; set; }

        public string  AgentUserName { get; set; }

        public string AgentPassword { get; set; }

        public string  RegisterUrl { get; set; }

        public string  PostUrl { get; set; }  

        public string  Token { get; set; }  

        public string SRCMSISDN {get; set;}

        public string SRCMSISDN_FRGN {get; set;}

        public string VARIANT_ID {get; set;}

        public string VARIANT_ID_FRGN {get; set;}

        public string MSGCODE { get; set; }  

        public string MSGCODE_FRGN { get; set; }

        public string AlternatePosturl {get; set;}

        public List<OriginatorInfo> Originators {get; set;}

        public OriginatorInfo GetDefaultOriginator()
        {
            if (Originators == null )
            {
                return null;
            }
            return Originators.Find(p => p.IsDefault == true);       
        }
    }
}