using System;

namespace DMessageCoreCommon.Model
{
    public class RegisterTokenModel  : EntityBase
    {
        public Guid BusinesUnitId { get; set; }

        public AgentType  AgentType { get; set; }

        public string AgentUser { get; set; }

        public string Token { get; set; }

        public DateTime TokenTime { get; set; }

        public override string GetSubCollectionName()
        {
            return "Token";
        }
    }
}