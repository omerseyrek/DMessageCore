namespace DMessageCoreCommon.Model
{
    public enum ApnsPostTyppe
    {
        Notification = 1,
        Data = 2
    }
}