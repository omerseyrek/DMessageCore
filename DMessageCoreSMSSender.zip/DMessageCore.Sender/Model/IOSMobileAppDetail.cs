﻿using System;

namespace DMessageCoreCommon.Model
{
    public class AppleMobileAppDetail
    {
        public string Name { get; set; }
        public string  CertificatePassword { get; set; }

        public Byte[]  CertificateFile  { get; set; }

        public ApnsServerVersion Apns { get; set; }

        public ApnsPostTyppe PostType { get; set; }
    }
}