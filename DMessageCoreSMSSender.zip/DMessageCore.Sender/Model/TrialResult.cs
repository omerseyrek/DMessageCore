﻿using System;

namespace DMessageCoreCommon.Model
{
    public class TrialResult 
    {
        public TrialResult()
        {
            this.TrialSucces = false;
            this.ProviderResponse = "";
            this.Processdate = DateTime.UtcNow;
        }
        public bool TrialSucces { get; set; }

        public string ErrorCode { get; set; }

        public string ErrorMessage { get; set; }

        public DateTime Processdate { get; set; }

        public string ProviderResponse { get; set; }
    }
}