﻿
namespace DMessageCoreCommon.Model
{
    public class AndroidMobileAppDetail
    {
        public string  ApiKey { get; set; }

        public string AndroidJson { get; set; }

        public ApnsServerVersion Apns { get; set; }

        public ApnsPostTyppe PostType { get; set; }

    }
}