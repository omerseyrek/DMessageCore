namespace DMessageCoreCommon.Model
{
    public class EMailProviderParameters
    {
        public AgentType AgentType { get; set; }

        public string  AgentUserName { get; set; }

        public string AgentPassword { get; set; }

        public string  RegisterUrl { get; set; }

        public string  PostUrl { get; set; }  

       
        public string  FromName { get; set; }  

        
        public string  FromAddres { get; set; }  

        
        public string  ReplayAddres { get; set; }  

        public string Token { get; set; }

        
    }
}