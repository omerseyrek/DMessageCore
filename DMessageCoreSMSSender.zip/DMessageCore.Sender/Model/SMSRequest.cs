
namespace DMessageCoreSMSSender.Model
{
    public class SMSRequest 
    {
        public int Customer { get; set; }   

        public string CustomerName { get; set; }    

        public string Originator { get; set; }

        public string PhoneNumber { get; set; }

        public string Subject { get; set; }

        public string Message { get; set; }

        public string ExternalId { get; set; }
    }
}