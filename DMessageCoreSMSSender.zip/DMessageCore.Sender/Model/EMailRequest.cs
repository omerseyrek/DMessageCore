﻿
namespace DMessageReceiver.Model
{
    public class EMailRequest 
    {
        public int Customer { get; set; }   

        public string FromName { get; set; }    

        public string FromAddress { get; set; }

        public string ReplayAddress { get; set; }

        public string Subject { get; set; }

        public string HtmlBody { get; set; }

        public string CharSet { get; set; }

        public string ToName { get; set; }

        public string ToEmailAddress { get; set; }
    }
}
