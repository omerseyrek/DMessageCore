using System;
using System.Collections.Generic;
using DMessageCoreCommon.Model;

namespace DMessageReceiver.ServiceLayer
{
    public class NotificationQueItem : EntityBase
    {
        public Guid BussinesClientId { get; set; }

        public MobileApp MobileApp { get; set; }

        public NotificationRequest NotificationRequest { get; set; }

        public List<TrialResult> TrialResults { get; set; }

        public override string GetSubCollectionName()
        {
            return "NotificationQue";
        }
    }
}