using System;
using System.Collections.Generic;
using DMessageCoreSMSSender.Model;

namespace DMessageCoreCommon.Model
{
    public class SMSQueItem : EntityBase, ITokenField
    {
        public Guid BussinesClientId { get; set; }

        public bool IsFastApi { get; set; }

        public SMSProviderParameters SMSProvider { get; set; }

        public SMSRequest SMSRequest { get; set; }

        public List<TrialResult> TrialResults { get; set; }

        public string AgentNameProxy { get => SMSProvider.AgentUserName ; set => SMSProvider.AgentUserName = value; }

        public string AgentPasswordProxy { get => SMSProvider.AgentPassword; set => SMSProvider.AgentPassword = value; }

        public string TokenProxy { get => SMSProvider.Token; set => SMSProvider.Token = value; }

        public AgentType AgentTypeProxy { get => SMSProvider.AgentType; set => SMSProvider.AgentType = value; }

        public Guid BussinesClientIdProxy { get => BussinesClientId; set => BussinesClientId = value; }

        public override string GetSubCollectionName()
        {
            return "SMSQue";
        }


    }
}