using System;
using System.Collections.Generic;
using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.Model;

namespace DMessageCoreSMSSender.ServiceLayer
{
    public interface IRequestSenderService 
    {
        void Push(SMSQueItem request, Guid BusinessClientId);
    }

    public interface ISMSRequestSenderService : IRequestSenderService
    {

    }
    public interface IEmailRequestSenderService : IRequestSenderService
    {
        
    }

    public interface IPushRequestSenderService : IRequestSenderService
    {
        
    }
}
