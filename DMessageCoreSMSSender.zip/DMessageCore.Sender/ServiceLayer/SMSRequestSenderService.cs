using System;
using DMessageCoreCommon.Model;
using DMessageCoreCommon.MQLayer;

namespace DMessageCoreSMSSender.ServiceLayer {

    public class SMSRequestSenderService : ISMSRequestSenderService {

        private readonly IMQManager<SMSQueItem> _mqSMSQueManager;
        public SMSRequestSenderService (IMQManager<SMSQueItem> mqManager) {

            _mqSMSQueManager = mqManager;
        }

        public void Push (SMSQueItem request, Guid BusinessClientId) 
        {
            _mqSMSQueManager.PushSMSResult (request);
        }

    }

}