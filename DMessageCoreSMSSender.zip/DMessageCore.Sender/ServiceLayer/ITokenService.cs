using System;
using DMessageCoreCommon.Model;

namespace DMessageCoreSMSSender.ServiceLayer
{
    public interface ITokenService 
    {
        RegisterTokenModel GetTokenRecentToken(RegisterTokenModel registerTokenModel);
        void RegisterToken(Action<ITokenField> registerAction, ITokenField itemToRegister,  TrialResult trialResult);
    }
}
