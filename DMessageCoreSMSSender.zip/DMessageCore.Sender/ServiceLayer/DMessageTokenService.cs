using System;
using DMessageCoreCommon.Model;
using DMessageCoreCommon.MQLayer;
using DMessageCoreSender.DBLayer;

namespace DMessageCoreSMSSender.ServiceLayer
{
    public class DMessageTokenService : ITokenService
    {
        private IDBLayer<RegisterTokenModel> _dbToken;
        private IMQManager<RegisterTokenModel> _messageQueManager;

        public DMessageTokenService(IDBLayer<RegisterTokenModel> dbToken,  IMQManager<RegisterTokenModel> messageQueManager)
        {
            _dbToken = dbToken;
            _messageQueManager = messageQueManager;
        }


        public RegisterTokenModel GetTokenRecentToken(RegisterTokenModel registerTokenModel)
        {
            var token = _dbToken.FindOne(p => p.BusinesUnitId == registerTokenModel.BusinesUnitId
                                        && p.AgentType == registerTokenModel.AgentType
                                        && p.AgentUser == registerTokenModel.AgentUser
                                        && p.TokenTime > DateTime.UtcNow.AddSeconds(-60)
                                        , o => o.TokenTime, true);
            return token;
        }

        /// <summary>
        /// tries the register proces with given acrion and parameter
        /// if catches exception adds that into given items trialresult que
        /// if refistration is unseccesfull theb adds the results to  trialresult que
        /// if a naw token is retrieved from action then saves it to db, and pushes the new token to messaging quee.
        /// </summary>
        public void RegisterToken(Action<ITokenField> registerAction, ITokenField itemToRegister, TrialResult trialResult)
        {
            try
            {
                CallRegisterActionAsLocked(registerAction, itemToRegister);
            }
            catch (System.Exception ex)
            {
                trialResult.ErrorCode = Common.ProviderRegisterException;
                trialResult.ErrorMessage = ex.Message;
                trialResult.TrialSucces = false;
                return;
            }

            if (itemToRegister.TokenProxy.IndexOf(Common.InvalidSessionToken) != -1)
            {
                trialResult.ErrorCode = Common.ProviderRegisterFailure;
                trialResult.ErrorMessage = itemToRegister.TokenProxy;
                trialResult.TrialSucces = false;
                return;
            }

            RegisterTokenModel tokenModel = new RegisterTokenModel()
            {
                BusinesUnitId = itemToRegister.BussinesClientIdProxy,
                AgentType = itemToRegister.AgentTypeProxy,
                AgentUser = itemToRegister.AgentNameProxy,
                Token = itemToRegister.TokenProxy,
                TokenTime = DateTime.Now,
            };

            _dbToken.save(tokenModel);

            _messageQueManager.PushNewSMSToken(tokenModel);
        }


        private void CallRegisterActionAsLocked(Action<ITokenField> registerAction, ITokenField itemToRegister)
        { 
             var lockObject = new object();

            lock (lockObject)
            { 
                RegisterTokenModel tokenModel = new RegisterTokenModel()
                {
                    BusinesUnitId = itemToRegister.BussinesClientIdProxy,
                    AgentType = itemToRegister.AgentTypeProxy,
                    AgentUser = itemToRegister.AgentNameProxy
                };

                RegisterTokenModel tokenModelReult = GetTokenRecentToken(tokenModel);
                if (tokenModelReult == null)
                {
                    registerAction(itemToRegister);
                }
                else
                {
                    itemToRegister.TokenProxy = tokenModelReult.Token;
                }

            }
        }


    }



}