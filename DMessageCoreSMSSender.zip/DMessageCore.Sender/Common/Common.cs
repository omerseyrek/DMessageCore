
using System.Text.RegularExpressions;

namespace DMessageCoreSMSSender.ServiceLayer {
    public static class Common {
        public static readonly string TurkcellInvalidSessionCode = "1000";

        public static readonly string ProviderRegisterException = "1001";

        public static readonly string ProviderRegisterFailure = "1002";

        public static readonly string ProviderPushException = "1003";

        public static readonly string TrialResultExceeded = "1004";

        public static readonly string CodecDeserializationFailureResult = "1005";

        public static readonly string CodecInvalidSessionCode = "1007";

        public static readonly string CodecFastApiCallFailure = "1008";

        public static readonly string EuroMessageInvalidSessionCode = "1007";

        public static readonly string DMessageCoreGeneralException = "9999";

        public static readonly string CodecInvalidSessionText = "Invalid Codec session";

        public static readonly string TurkcellInvalidSessionText = "NOK,-2,Invalid session";

        public static readonly string EuroMessageInvalidSessionText = "NOK,-2,Invalid session";

        public static readonly string TrialResultExceededText = "Trial result exceeded";

        public static readonly string InvalidSessionToken = "NOK";

        public static readonly string CodecDeserializationFailureResultText = "Failed to deserialize codec SendSMS result";

        public static readonly string CodecFastApiCallFailureText = "failed to call codec fast api service";

        public static readonly string EuroMessageInvalidSessionCodeText = "Invalid Euromessage Session";

        public static bool IsAbroad (string PhoneNumber) {
            if (PhoneNumber.StartsWith ("0090")) //00905454035133 
            {
                return false;
            }
            if (PhoneNumber.StartsWith ("90")) //905454035133 
            {
                return false;
            }
            if (PhoneNumber.Length <= 10) //5454035133 
            {
                return false;
            }

            return true;
        }

        public static bool HasTurkischChars (string content) {
            return !IsGSM7Bit (content);
        }

        private static bool IsGSM7Bit (string smstext) {
            var regexp = new Regex ("^[A-Za-z0-9 \\r\\n@£$¥èéùìòÇØøÅå\u0394_\u03A6\u0393\u039B\u03A9\u03A0\u03A8\u03A3\u0398\u039EÆæßÉ!\"#$%&'()*+,\\-./:;<=>?¡ÄÖÑÜ§¿äöñüà^{}\\\\\\[~\\]|\u20AC]*$");

            var result = regexp.IsMatch (smstext);

            return result;

        }
    }

    public static class QueNames {
        public static readonly string ServiceClientParamterExchangeQue = "SMS-parameter";
        public static readonly string SmsPushResult = "sms-push-result";
        public static readonly string EmailPushResult = "email-push-result";
        public static readonly string NotificationPushResult = "notification-push-result";
        public static readonly string PushSMSTokenResult = "token-exchange";
        public static readonly string PushEmailTokenResult = "token-exchange";


        public static readonly string SMSPushExchangeQue = "sms-push-exchange";
        public static readonly string SMSFastPushExchangeQue = "sms-shot-push-exchange";
        public static readonly string EMailPushExchangeQue = "email-push-exchange";
        public static readonly string NotificationPushExchangeQue = "notification-push-exchange";
    }


    public static class ProcessMessages
    {
        public static readonly string SavedSMSQueItem = "Receiver - SMS gönderim kuyruğuna Kaydedildi ";
        public static readonly string PushingSMSQueItemToShot = "Receiver - SMS hızlı messaj veri tabanı kuyruğuna kaydedildi";
        public static readonly string PushingSMSQueItem = "Receiver - SMS messaj kuyruğuna kaydediliyor";
        public static readonly string PushedSMSQueItemToShot = "Receiver - SMS hızlı messaj kuyruğuna kaydedildi";
        public static readonly string PushedSMSQueItem = "Receiver - SMS messaj kuyruğuna kaydedildi";
        public static readonly string SmsResultReceived = "Receiver - SMS gönderim sonucu değeri alındı";
        public static readonly string SmsResultSaved = "Receiver - SMS gönderim sonucu değeri kaydedildi";

        public static readonly string SmsPushProcessStarted = "Sender - SMS gönderim süreci başladı";
        public static readonly string SmsPushProcessCompleted = "Sender - SMS gönderim süreci tamamlandı";


        public static readonly string SmsShotPushProcessStarted = "Sender - SMS Shot gönderim süreci başladı";
        public static readonly string SmsShotPushProcessCompleted = "Sender - SMS Shot gönderim süreci tamamlandı";
        public static readonly string FirstSmsTrial = "Sender - SMS gönderimi 1. deneme";
        public static readonly string SecondSmsTrial = "Sender - SMS gönderimi 2. deneme";
        public static readonly string ThirdSmsTrial = "Sender - SMS gönderimi 3. deneme";
        public static readonly string PushSMSResultToMessageQue = "Sender - SMS  gönderim süreci sonucu mesaj kuyruğuna iletildi";
        public static readonly string PushSMSException = "Sender - SMS gönderim süreci hata aldı";


        public static readonly string EmailPushProcessStarted = "Sender - Email gönderim süreci başladı";
        public static readonly string EmailPushProcessCompleted = "Sender - Email gönderim süreci tamalandı";
        public static readonly string SavedEMailQueItem = "Receiver - EMail gönderim  veri tabanı kuyruğuna kaydedildi ";
        public static readonly string PushingEMailQueItem = "Receiver - EMail messaj kuyruğuna kaydediliyor";
        public static readonly string PushedEMailQueItem = "Receiver - EMail messaj kuyruğuna kaydedildi";
        public static readonly string EmailResultReceived = "Receiver - eMail gönderim sonucu değeri alındı";
        public static readonly string EmailResultSaved = "Receiver - eMail gönderim sonucu değeri kaydedildi";
        public static readonly string FirstEmailTrial = "Sender - eMail gönderimi 1. deneme";
        public static readonly string SecondEmailTrial = "Sender - eMail gönderimi 2. deneme";
        public static readonly string ThirdEmailTrial = "Sender - eMail gönderimi 3. deneme";
        public static readonly string PushEmailResultToMessageQue = "Sender - eMail  gönderim süreci sonucu mesaj kuyruğuna iletildi";
        public static readonly string PushEmailException = "Sender - eMail gönderim süreci hata aldı";

        public static readonly string SavedNotificationQueItem = "Receiver - Notification veri tabanı kuyruğuna kaydedildi ";
        public static readonly string PushingNotificationQueItem = "Receiver - Notification messaj kuyruğuna kaydediliyor";
        public static readonly string PushedNotificationQueItem = "Receiver - Notification messaj kuyruğuna kaydedildi";
        public static readonly string NotificationResultReceived = "Receiver - Notification gönderim sonucu değeri alındı";
        public static readonly string NotificationResultSaved = "Receiver - Notification gönderim sonucu değeri kaydedildi";
        public static readonly string NotificationPushProcessStarted = "Sender - Notification gönderim süreci başladı";
        public static readonly string NotificationPushProcessCompleted = "Sender - Notification gönderim süreci tamamlandı";
        public static readonly string NotificationTrial = "Sender - Notification gönderimi sonucu";
        public static readonly string PushNotificationResultToMessageQue = "Sender - Notification  gönderim süreci sonucu mesaj kuyruğuna iletildi";
        public static readonly string PushNotificationException = "Sender - Notification gönderim süreci hata aldı";


        public static readonly string SMSTokenResultReceived = "Receiver - Token result received";
        public static readonly string SMSTokenResultSaved = "Receiver - Token result saved";

        public static readonly string EMailTokenResultReceived = "Receiver - Token result received";
        public static readonly string EMailTokenResultSaved = "Receiver - Token result saved";

        public static readonly string ParamterChangeReceived = "Receiver - Paramter change received";

        public static readonly string ParamterChangeSaved = "Receiver - Paramter change saved";

    }
}