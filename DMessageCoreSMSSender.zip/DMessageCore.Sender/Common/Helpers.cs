using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace DMessageCoreSMSSender.ServiceLayer {
    public static class Helper {

        public static string ConvertXml (Object obj) {
            System.Xml.Serialization.XmlSerializer xsSubmit = new System.Xml.Serialization.XmlSerializer (obj.GetType ());

            var xns = new XmlSerializerNamespaces ();
            xns.Add (string.Empty, string.Empty);

            XmlWriterSettings xmlWriterSettings = new XmlWriterSettings {
                Indent = true,
                OmitXmlDeclaration = false,
                Encoding = Encoding.UTF8
            };

            using (StringWriter sww = new StringWriter ()) {
                using (XmlWriter writer = XmlWriter.Create (sww, xmlWriterSettings)) {
                    xsSubmit.Serialize (writer, obj, xns);
                    var xml = sww.ToString ();

                    return xml.Replace ("utf-16", "UTF-8").Replace ("<string>", "").Replace ("</string>", "").Replace ("_CONCAT", "");
                }
            }
        }
    }
}