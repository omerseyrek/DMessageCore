﻿using Microsoft.AspNetCore.Mvc;

namespace DMessageCoreSMSSender.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        public WeatherForecastController()
        {
        }

    }
}
