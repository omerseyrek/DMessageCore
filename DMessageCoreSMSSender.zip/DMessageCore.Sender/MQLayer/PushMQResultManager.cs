using System.Text;
using System.Text.Json;
using DMessageCoreCommon.Model;
using DMessageCoreSMSSender;
using DMessageCoreSMSSender.ServiceLayer;
using RabbitMQ.Client;

namespace DMessageCoreCommon.MQLayer
{
    public class PushMQResultManager<T> : IMQManager<T> where T : EntityBase, new()
    {
       

        public void BasePush(T record, string exchangeName)
        {
            var factory =  RabbitHelper.GetConnectionFactory;

            using(var connection = factory.CreateConnection())
            using(var channel = connection.CreateModel())
            {
                string message  = JsonSerializer.Serialize(record);
                var body = Encoding.UTF8.GetBytes(message);

                channel.BasicPublish(exchange:  exchangeName,
                                    routingKey: "",
                                    basicProperties: null,
                                    body: body);
            }
         }


        public void PushSMSResult(T record)
        {
            BasePush(record, QueNames.SmsPushResult);
        }

        public void PushEmailResult(T record)
        {
            BasePush(record, QueNames.EmailPushResult);
        }

        public void PushNotificationResult(T record)
        {
            BasePush(record, QueNames.NotificationPushResult);
        }

        public void PushNewSMSToken(T record)
        {
            BasePush(record, QueNames.PushSMSTokenResult);
        }

        public void PushNewEmailToken(T record)
        {
            BasePush(record, QueNames.PushEmailTokenResult);
        }
    }
}
