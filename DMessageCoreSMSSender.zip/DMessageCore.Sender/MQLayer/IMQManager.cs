using DMessageCoreCommon.Model;

namespace DMessageCoreCommon.MQLayer
{
    public interface IMQManager<in T> where T : EntityBase, new()
    {
        void PushSMSResult(T record);

        void PushEmailResult(T record);

        void PushNotificationResult(T record);

        void PushNewSMSToken(T record);

       void PushNewEmailToken(T record);

    }
}

