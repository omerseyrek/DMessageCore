using System;
using System.Linq;
using System.Net.Mime;
using System.Text;
using DMessageCore.Logging;
using DMessageCore.Logging.Models;
using DMessageCoreCommon.DBLayer;
using DMessageCoreCommon.MQLayer;
using DMessageCoreSender.DBLayer;
using DMessageCoreSMSSender.ServiceLayer;
using Elastic.Apm.NetCoreAll;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace DMessageCoreSMSSender {
    public class Startup {
        public Startup (IConfiguration configuration) {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices (IServiceCollection services) {
            services.AddSwaggerGen (c => {
                c.SwaggerDoc ("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "DMessage Core Sender API", Description = "DMessage Core Sender API", Version = "v1" });
                c.OperationFilter<AuthOperationAttribute> ();
            });

            services.AddSingleton<IConfiguration> (Configuration);
            ConfigurationProxy.Configuration = Configuration;

            services.AddAuthentication (JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer (jwtBearerOptions => {
                    jwtBearerOptions.TokenValidationParameters = new TokenValidationParameters () {
                    ValidateActor = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Configuration["Issuer"],
                    ValidAudience = Configuration["Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey (Encoding.UTF8.GetBytes (Configuration["SigningKey"]))
                    };
                });
            Microsoft.IdentityModel.Logging.IdentityModelEventSource.ShowPII = true;

            services.AddHealthChecks ()
                .AddCheck<RabbitMQHealthCheck> ("RabbitMQ");

            services.AddSingleton<RabbitListener> ();

            services.AddScoped (typeof (ISMSRequestSenderService), typeof (SMSRequestSenderService));
            services.AddSingleton (typeof (ITokenService), typeof (DMessageTokenService));
            services.AddSingleton (typeof (IMQManager<>), typeof (PushMQResultManager<>));
            services.AddSingleton(typeof(IDBLayer<>), typeof(MongoDBLayer<>));
            services.AddSingleton(typeof(ICustomLogging<LogModel>), typeof(CustomLogging<LogModel>));
            services.AddControllers ().AddNewtonsoftJson();

            services.AddMvc ().SetCompatibilityVersion (CompatibilityVersion.Version_3_0);

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        [Obsolete]
        public void Configure (IApplicationBuilder app, IWebHostEnvironment env) {
            if (env.IsDevelopment ()) {
                app.UseDeveloperExceptionPage ();
            }

            app.UseCustomLogging(this.Configuration);

            app.UseAllElasticApm(this.Configuration);

            app.UsePathBase (Configuration["basePath"]);

            app.UseRabbitListener ();

            app.UseRouting ();

            app.UseAuthentication();
            app.UseAuthorization();
            
            var healthOptions = new HealthCheckOptions ();
            healthOptions.ResultStatusCodes[HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable;
            healthOptions.ResponseWriter = async (ctx, rpt) => {
                var result = JsonConvert.SerializeObject (new {
                    status = rpt.Status.ToString (),
                        errors = rpt.Entries.Select (e => new { key = e.Key, value = Enum.GetName (typeof (HealthStatus), e.Value.Status) })
                }, Formatting.None, new JsonSerializerSettings () {
                    NullValueHandling = NullValueHandling.Ignore
                });
                ctx.Response.ContentType = MediaTypeNames.Application.Json;
                await ctx.Response.WriteAsync (result);
            };
            app.UseHealthChecks ("/healthcheck", healthOptions);

            app.UseEndpoints (endpoints => {
                endpoints.MapControllers ();
            });

            app.UseSwagger ();

            app.UseSwaggerUI (c => {
                c.SwaggerEndpoint ("../swagger/v1/swagger.json", "DMessage Core Sender API v1.0");
            });
        }

    }

}