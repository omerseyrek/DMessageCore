using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DMessageCoreSMSSender;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using RabbitMQ.Client;

namespace DMessageCoreSMSSender
{
    public class RabbitMQHealthCheck : IHealthCheck
    {

        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            try
            {
                var factory = RabbitHelper.GetConnectionFactory;

                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    channel.QueueDeclare(queue: "HealthCheck",
                        durable: false,
                        exclusive: false,
                        autoDelete: false,
                        arguments: null);

                    channel.BasicAcks += (sender, eventArgs) =>
                    {

                    };

                    channel.ConfirmSelect();

                    string message = "Push Healtheck Message";
                    var body = Encoding.UTF8.GetBytes(message);

                    channel.BasicPublish(exchange: "HealthCheck",
                        routingKey: "HealthCheck",
                        basicProperties: null,
                        body: body);

                    channel.WaitForConfirmsOrDie();
                }

                return Task.FromResult(HealthCheckResult.Healthy("Succeed To To Connect rabbit MQ", null));
            }
            catch (Exception ex)
            {
                return Task.FromResult(HealthCheckResult.Unhealthy("Failed To To Connect Rabbit MQ", ex, null));
            }
        }
    }
}