namespace DMessageCore.Sender
{
    using DMessageCoreCommon.Model;
    public interface ISMSProvider
    {
        TrialResult Send(SMSQueItem item);

    }
}
