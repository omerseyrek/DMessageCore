﻿
using System.Collections.Generic;

namespace DMessageCore.Sender.TurkcellEntities
{
    public class TM_CONCAT
    {
        public DST_MSISDN_LIST DST_MSISDN_LIST { get; set; }
        public List<CONTENT_CONCAT> CONTENT_LIST { get; set; }
    }
}
