﻿using System.Collections.Generic;

namespace DMessageCore.Sender.TurkcellEntities
{
    public class CONTENT_CONCAT
    {
        public string RPID { get; set; }

        public string MCLS { get; set; }

        public List<CITEM> CITEM_LIST { get; set; }
    }
}
