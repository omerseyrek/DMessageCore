﻿using System.Collections.Generic;

namespace DMessageCore.Sender.TurkcellEntities
{
    public class SENDSMS
    {
        public string VERSION { get; set; }
        public string SESSION_ID { get; set; }
        public string CONTENT_ID { get; set; }
        public string CHARGING_MULT { get; set; }
        public string MSG_CODE { get; set; }
        public string VARIANT_ID { get; set; }
        public string SDATE { get; set; }
        public string DDATE { get; set; }
        public string VP { get; set; }
        public string SRC_MSISDN { get; set; }
        public string SENDER { get; set; }
        public string NOTIFICATION { get; set; }
        public List<TM> TM_LIST { get; set; }
    }
}
