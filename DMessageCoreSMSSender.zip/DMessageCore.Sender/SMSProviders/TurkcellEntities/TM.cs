﻿using System.Collections.Generic;

namespace DMessageCore.Sender.TurkcellEntities
{
    public class TM
    {
        public DST_MSISDN_LIST DST_MSISDN_LIST { get; set; }
        public List<CONTENT> CONTENT_LIST { get; set; }
    }
}
