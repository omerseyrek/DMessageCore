﻿namespace DMessageCore.Sender.TurkcellEntities
{
    public class CITEM
    {
        public string CITEM_TEXT { get; set; }

        public string XSER { get; set; }
    }
}
