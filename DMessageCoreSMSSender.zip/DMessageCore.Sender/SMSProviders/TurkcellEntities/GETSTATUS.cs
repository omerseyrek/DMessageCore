﻿namespace DMessageCore.Sender.TurkcellEntities
{
    public class GETSTATUS
    {
        public string VERSION { get; set; }
        public string SESSION_ID { get; set; }
        public MSGID_LIST MSGID_LIST { get; set; }
    }
}
