﻿namespace DMessageCore.Sender.TurkcellEntities
{
    public class REGISTER
    {
        public string VERSION { get; set; }
        public REG REG { get; set; }
    }
}
