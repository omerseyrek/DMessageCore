﻿using System.Collections.Generic;

namespace DMessageCore.Sender.TurkcellEntities
{
    public class MSGID_LIST
    {
        public List<string> MSGID { get; set; }
    }
}
