﻿namespace DMessageCore.Sender.TurkcellEntities
{
    public class REG
    {
        public string USER { get; set; }
        public string PASSWORD { get; set; }
    }
}
