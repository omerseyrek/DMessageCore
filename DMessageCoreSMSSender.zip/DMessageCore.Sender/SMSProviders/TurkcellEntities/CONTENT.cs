﻿namespace DMessageCore.Sender.TurkcellEntities
{
    public class CONTENT
    {
        public string CONTENT_TEXT { get; set; }
    }
}
