﻿namespace DMessageCore.Sender.TurkcellEntities
{
    public class DST_MSISDN_LIST
    {
        public string DST_MSISDN { get; set; }
    }
}
