﻿using DMessageCoreCommon.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EuroMessageAuth;
using EuroMessageSMS;
using DMessageCoreSMSSender.ServiceLayer;
using System.ServiceModel;

namespace DMessageCore.Sender.SMSProviders.EuroMessage
{
    public class EuroMessageSMSProvider : ISMSProvider
    {
        private ITokenService _tokenService;

        public EuroMessageSMSProvider(ITokenService tokenService)
        {
            _tokenService = tokenService;
        }
        
        /// <summary>
        /// todo : turkcell ile aynı yapıda kod bloğu oluştu, ortaklaştırılması uygun olacaktır
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public TrialResult Send(SMSQueItem item)
        {
            TrialResult trialResult = null;

            if ((item.TrialResults?.Count ?? 0) >= 3)
            {
                trialResult = new TrialResult();
                trialResult.ErrorCode = Common.TrialResultExceeded;
                trialResult.ErrorMessage = Common.TrialResultExceededText;
                trialResult.TrialSucces = false;
                return trialResult;
            }

            if ((item.TrialResults?.Count ?? 0) == 0 && !string.IsNullOrEmpty(item.SMSProvider?.Token ?? string.Empty))
            {
                return SendToProvider(item);
            }

            RegisterTokenModel tokenModel = new RegisterTokenModel()
            {
                BusinesUnitId = item.BussinesClientId,
                AgentType = item.SMSProvider.AgentType,
                AgentUser = item.SMSProvider.AgentUserName
            };

            RegisterTokenModel tokenModelReult = _tokenService.GetTokenRecentToken(tokenModel);
            if (tokenModelReult != null && (item.TrialResults?.Count ?? 0) < 3)
            {
                item.SMSProvider.Token = tokenModelReult.Token;
            }
            else
            {
                trialResult = new TrialResult();
                Action<ITokenField> registerAction = Register;
                _tokenService.RegisterToken(registerAction, item, trialResult);
                if (!String.IsNullOrEmpty(trialResult.ErrorCode)) //register işlemi başarısız ise..
                {
                    return trialResult;
                }
            }

            trialResult = SendToProvider(item);
            return trialResult;

        }


        private TrialResult SendToProvider(SMSQueItem item)
        {
            TrialResult trialResult = new TrialResult();

            PostSmsSoapClient.EndpointConfiguration epc = new PostSmsSoapClient.EndpointConfiguration();
            PostSmsSoapClient smsClient = new PostSmsSoapClient(epc);
            EmPostSmsResult postRes = null;

            if (string.IsNullOrEmpty(item.SMSRequest.Originator) && (item.SMSProvider.Originators?.Count ?? 0) > 0)
            {
                item.SMSRequest.Originator = item.SMSProvider.GetDefaultOriginator().Originator;
            }

            if (item.IsFastApi)
            {

                EmKeyValue[] messageNumberPair = new EmKeyValue[1];
                messageNumberPair[0] = new EmKeyValue();
                messageNumberPair[0].Key = item.SMSRequest.PhoneNumber;
                messageNumberPair[0].Value = item.SMSRequest.Message;

                postRes = smsClient.SingleShotSmsAsync(item.SMSProvider.Token, item.SMSRequest.Originator, messageNumberPair, string.Empty).Result;
            }
            else
            {
                string[] gsmNumbers = new String[] { item.SMSRequest.PhoneNumber };
                postRes = smsClient.SendBulkSmsAsync(item.SMSProvider.Token, item.SMSRequest.Originator, item.SMSRequest.Message, gsmNumbers, string.Empty, string.Empty).Result;
            }

            trialResult.Processdate = DateTime.UtcNow;

            if (postRes != null)
            {
                if (postRes.Code == "00")
                {
                    trialResult.TrialSucces = true;
                    trialResult.ErrorMessage = "";
                    trialResult.ProviderResponse = postRes.PacketID;
                }
                else
                {
                    if (postRes.Code == "9998")
                    {
                        trialResult.ErrorCode = Common.EuroMessageInvalidSessionCode;
                        trialResult.TrialSucces = false;
                        trialResult.ErrorMessage = Common.EuroMessageInvalidSessionCodeText;
                    }
                    else
                    {
                        trialResult.ErrorCode = Common.DMessageCoreGeneralException;
                        trialResult.TrialSucces = false;
                        trialResult.ErrorMessage = postRes.Message;
                    }
                }
                return trialResult;
            }
            else
            {
                trialResult.ErrorCode = Common.DMessageCoreGeneralException;
                trialResult.TrialSucces = false;
                trialResult.ErrorMessage = "Euromessage Empty Result";
                return trialResult;
            }
        }


        private void Register(ITokenField smsQueItemProxy)
        {
            SMSQueItem item = (SMSQueItem)smsQueItemProxy;

            var binding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport);
            var endpoint = new EndpointAddress(new Uri(item.SMSProvider.RegisterUrl));
            var channelFactory = new ChannelFactory<EuroMessageAuth.AuthSoap>(binding, endpoint);
            var serviceClient = channelFactory.CreateChannel();

            EmAuthResult authResult = serviceClient.LoginAsync(item.SMSProvider.AgentUserName, item.SMSProvider.AgentPassword).Result;

            if (authResult.Code == "00")
            {
                item.SMSProvider.Token = authResult.ServiceTicket;
            }
            else
            {
                item.SMSProvider.Token = Common.InvalidSessionToken + " - " + authResult.Code + " - " + authResult.Message;
            }
        }

    }
}
