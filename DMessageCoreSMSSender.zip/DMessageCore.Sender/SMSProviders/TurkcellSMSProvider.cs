namespace DMessageCore.Sender {
    using System.Collections.Generic;
    using System;
    using DMessageCore.Sender.TurkcellEntities;
    using DMessageCoreCommon.Model;
    using DMessageCoreSMSSender.ServiceLayer;


    public class TurkcellSMSProvider : ISMSProvider {
        private ITokenService _tokenService { get; }

        public TurkcellSMSProvider(ITokenService tokenService)
        {
            _tokenService = tokenService;
        }

        public TrialResult Send(SMSQueItem item) 
        {
            TrialResult trialResult = null;

            if ((item.TrialResults?.Count ?? 0) >= 3)
            {
                trialResult = new TrialResult();
                trialResult.ErrorCode = Common.TrialResultExceeded;
                trialResult.ErrorMessage = Common.TrialResultExceededText;
                trialResult.TrialSucces = false;
                return trialResult;
            }

            if ((item.TrialResults?.Count?? 0) == 0 && !string.IsNullOrEmpty(item.SMSProvider?.Token ?? string.Empty))
            {
                 return  SendToProvider(item);
            }
        
            RegisterTokenModel tokenModel = new RegisterTokenModel()
            {
                BusinesUnitId = item.BussinesClientId,
                AgentType = item.SMSProvider.AgentType,
                AgentUser = item.SMSProvider.AgentUserName
            };

            RegisterTokenModel tokenModelReult = _tokenService.GetTokenRecentToken(tokenModel);
            if (tokenModelReult != null && (item.TrialResults?.Count ?? 0) < 3)
            {
                 item.SMSProvider.Token = tokenModelReult.Token;
            }
            else
            {
                trialResult = new TrialResult();
                Action<ITokenField> registerAction = Register;
                _tokenService.RegisterToken(registerAction, item, trialResult);
                if (!String.IsNullOrEmpty(trialResult.ErrorCode)) //register işlemi başarısız ise..
                {
                    return trialResult;
                }
            }

            trialResult = SendToProvider(item);
            return trialResult;
        }

        private TrialResult SendToProvider(SMSQueItem item) {
            TrialResult trialResult = new TrialResult ();

            using (SendSMSPortClient client = new SendSMSPortClient ()) {
                var messageXML = CreateSMSContentXML (item);

                if (messageXML.Contains ("<CONTENT_CONCAT>")) {
                    client.Endpoint.Address = new System.ServiceModel.EndpointAddress (item.SMSProvider.AlternatePosturl); //the concat api
                } else {
                    client.Endpoint.Address = new System.ServiceModel.EndpointAddress (item.SMSProvider.PostUrl);
                }

                var trial = client.sendSMSAsync (messageXML);

                if (trial.Result.IndexOf("NOK") != -1)
                {
                    if (trial.Result.IndexOf (Common.TurkcellInvalidSessionText) != -1) {
                        trialResult.ErrorCode = Common.TurkcellInvalidSessionCode;
                        trialResult.TrialSucces = false;
                        trialResult.ErrorMessage = Common.TurkcellInvalidSessionText;
                    } else {
                        trialResult.TrialSucces = false;
                        trialResult.ErrorMessage = trial.Result;
                    }
                } 
                else {
                    var pushResult = trial.Result.Substring (trial.Result.IndexOf ("<MSGID>") + 7, trial.Result.IndexOf ("</MSGID>") - (trial.Result.IndexOf ("<MSGID>") + 7));
                    if (pushResult.IndexOf ("-") != -1) {
                        trialResult.TrialSucces = false;
                        trialResult.ErrorMessage = trial.Result;
                    } else {
                        trialResult.TrialSucces = true;
                        trialResult.ErrorMessage = "";
                        trialResult.ProviderResponse =  pushResult;
                    }
                }
            }
            return trialResult;
        }

        private string CreateSMSContentXML (SMSQueItem item) {
            if (item.SMSRequest.PhoneNumber.Length == 11) {
                item.SMSRequest.PhoneNumber = "9" + item.SMSRequest.PhoneNumber;
            } else if (item.SMSRequest.PhoneNumber.Length == 10) {
                item.SMSRequest.PhoneNumber = "90" + item.SMSRequest.PhoneNumber;
            }

            var senderText = "";
            var srcMSISDN = "";
            var variantIdText = "";

            if (Common.IsAbroad (item.SMSRequest.PhoneNumber)) {
                variantIdText = item.SMSProvider.VARIANT_ID_FRGN;
            } else {
                if ((item.SMSProvider.Originators?.Count ?? 0)> 0) {
                    senderText = item.SMSProvider.GetDefaultOriginator ().Originator;
                }
                else
                {
                    senderText = item.SMSRequest.Originator;
                }

                if (!string.IsNullOrEmpty (item.SMSProvider.SRCMSISDN)) {
                    srcMSISDN = item.SMSProvider.SRCMSISDN;
                }

                variantIdText = item.SMSProvider.VARIANT_ID;
            }

            var xmltext = string.Empty;
            int checkSizeLimit = 160;
            int sendSizeLimit = 153;

            if (Common.HasTurkischChars (item.SMSRequest.Message)) {
                checkSizeLimit = 70;
                sendSizeLimit = 67;
            }

            if (item.SMSRequest.Message.Length < checkSizeLimit) {
                var SENDSMS = new SENDSMS ();
                SENDSMS.CHARGING_MULT = "";
                SENDSMS.CONTENT_ID = "";
                SENDSMS.DDATE = "";
                SENDSMS.MSG_CODE = item.SMSProvider.MSGCODE;
                SENDSMS.NOTIFICATION = "T";
                SENDSMS.SDATE = "";
                SENDSMS.SENDER = senderText;
                SENDSMS.SESSION_ID = item.SMSProvider.Token;
                SENDSMS.SRC_MSISDN = srcMSISDN;
                SENDSMS.VARIANT_ID = variantIdText;
                SENDSMS.VERSION = "1.0";
                SENDSMS.VP = "";
                CONTENT CONTENT = new CONTENT ();

                CONTENT.CONTENT_TEXT = item.SMSRequest.Message;

                List<CONTENT> CONTENT_LIST = new List<CONTENT> ();
                CONTENT_LIST.Add (CONTENT);

                TM TM = new TM ();
                TM.CONTENT_LIST = CONTENT_LIST;
                DST_MSISDN_LIST DST_MSISDN_LIST = new DST_MSISDN_LIST ();
                DST_MSISDN_LIST.DST_MSISDN = SENDSMS.SRC_MSISDN == string.Empty ? item.SMSRequest.PhoneNumber.Substring (1) : item.SMSRequest.PhoneNumber;
                TM.DST_MSISDN_LIST = DST_MSISDN_LIST;
                List<TM> TM_LIST = new List<TM> ();
                TM_LIST.Add (TM);
                SENDSMS.TM_LIST = TM_LIST;
                xmltext = Helper.ConvertXml (SENDSMS);
            } else {
                var SENDSMS = new SENDCONCAT ();
                SENDSMS.DDATE = "";
                SENDSMS.MSG_CODE = item.SMSProvider.MSGCODE;
                SENDSMS.NOTIFICATION = "T";
                SENDSMS.SDATE = "";
                SENDSMS.SENDER = senderText;
                SENDSMS.SESSION_ID = "87681212370975197"; //use token here
                SENDSMS.SRC_MSISDN = srcMSISDN;
                SENDSMS.VARIANT_ID = variantIdText;
                SENDSMS.VERSION = "1.0";
                SENDSMS.VP = "";

                DST_MSISDN_LIST DST_MSISDN_LIST = new DST_MSISDN_LIST ();
                DST_MSISDN_LIST.DST_MSISDN = SENDSMS.SRC_MSISDN == string.Empty ? item.SMSRequest.PhoneNumber.Substring (1) : item.SMSRequest.PhoneNumber;

                TM_CONCAT TM = new TM_CONCAT ();
                CONTENT_CONCAT ContentConcat = new CONTENT_CONCAT ();
                ContentConcat.MCLS = "";
                ContentConcat.RPID = "";
                List<CITEM> CITEM_LIST = new List<CITEM> ();

                int messageCount = (item.SMSRequest.Message.Length / sendSizeLimit) + 1; //OS_20180105
                for (int i = 0; i < messageCount; i++) {
                    CITEM CITEM1 = new CITEM ();

                    if (i != messageCount - 1)
                        CITEM1.CITEM_TEXT = item.SMSRequest.Message.Substring (i * (sendSizeLimit - 1), (sendSizeLimit - 1)); //OS_0180105
                    else
                        CITEM1.CITEM_TEXT = item.SMSRequest.Message.Substring (i * (sendSizeLimit - 1));

                    CITEM1.XSER = "";
                    CITEM_LIST.Add (CITEM1);
                }

                ContentConcat.CITEM_LIST = CITEM_LIST;
                TM.DST_MSISDN_LIST = DST_MSISDN_LIST;
                List<CONTENT_CONCAT> CONTENT_LIST = new List<CONTENT_CONCAT> ();
                CONTENT_LIST.Add (ContentConcat);
                TM.CONTENT_LIST = CONTENT_LIST;
                List<TM_CONCAT> TM_LIST = new List<TM_CONCAT> ();
                TM_LIST.Add (TM);
                SENDSMS.TM_LIST = TM_LIST;
                xmltext = Helper.ConvertXml (SENDSMS);
            }

            return xmltext;
        }

        private void Register (ITokenField smsQueItemProxy) 
        {
            SMSQueItem smsQueItem = (SMSQueItem)smsQueItemProxy;

            RegisterPortClient turkcellRegisterClient = new RegisterPortClient ();
            turkcellRegisterClient.Endpoint.Address = new System.ServiceModel.EndpointAddress (smsQueItem.SMSProvider.RegisterUrl);

            REG REG = new REG ();
            REG.PASSWORD = smsQueItem.SMSProvider.AgentPassword;
            REG.USER = smsQueItem.SMSProvider.AgentUserName;

            REGISTER REGISTER = new REGISTER ();
            REGISTER.VERSION = "1.0";
            REGISTER.REG = REG;

            var registerAsync = turkcellRegisterClient.registerAsync (Helper.ConvertXml(REGISTER));

            var authenticationServiceKey = registerAsync.Result;

            if (authenticationServiceKey.IndexOf (Common.InvalidSessionToken) != -1) 
            {
                //log the register failure message
                smsQueItem.TokenProxy = Common.InvalidSessionToken + " - " + authenticationServiceKey;
            } else {
               smsQueItem.TokenProxy = authenticationServiceKey;
            };
        }
    }
}