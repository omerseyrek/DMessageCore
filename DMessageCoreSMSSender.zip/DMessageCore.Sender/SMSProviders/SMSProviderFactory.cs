namespace DMessageCore.Sender
{
    using DMessageCore.Sender.Codec;
    using DMessageCore.Sender.SMSProviders.EuroMessage;
    using DMessageCoreCommon.Model;
    using DMessageCoreSMSSender.ServiceLayer;

    public static class SMSProviderFactory
    {
        public static ISMSProvider GetSMSProvider(SMSQueItem item, ITokenService tokenService)
        {
            if (item.SMSProvider.AgentType == AgentType.Turkcell)
            {
                return new TurkcellSMSProvider(tokenService);
            }
            if (item.SMSProvider.AgentType == AgentType.Codec)
            {
                return CodecApiFactory.CreateApi(item);
            }
            if (item.SMSProvider.AgentType == AgentType.EuroMessage)
            {
                return new EuroMessageSMSProvider(tokenService);
            }
            else return null;
        }

    }
}

 
