using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Channels;
using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.ServiceLayer;

namespace DMessageCore.Sender.Codec
{
    public static class CodecApiFactory
    {
        public static ISMSProvider CreateApi(SMSQueItem item)
        {
            if (Common.IsAbroad(item.SMSRequest.PhoneNumber))
            {
                return new FastApi();
            }
            if (item.IsFastApi)
            {
                return new FastApi();
            }
            return new BulkApi();
        }

        public static FastApiSoapClient CreateFastApiClient(SMSProviderParameters providerParameter)
        {
            Binding fastApiBinding = new BasicHttpBinding(BasicHttpSecurityMode.Transport);
            EndpointAddress fastApiAdres = new EndpointAddress(providerParameter.PostUrl);
            FastApiSoapClient client = new FastApiSoapClient(fastApiBinding, fastApiAdres);
            return client;
        }

        public static seagull_SOAP_API_POSTPRE_CNCT008SoapClient CreateBulkApiClient(SMSProviderParameters providerParameter, bool useAlternative)
        {

            Binding bulkApiBinding = new BasicHttpBinding(BasicHttpSecurityMode.Transport);
            EndpointAddress bulkApiAdres = null;
            if (useAlternative)
            {
                bulkApiAdres = new EndpointAddress(providerParameter.AlternatePosturl);
            }
            else
            {
                bulkApiAdres = new EndpointAddress(providerParameter.AlternatePosturl); //to do : use alternate bulk Url.
            }

            seagull_SOAP_API_POSTPRE_CNCT008SoapClient client = new seagull_SOAP_API_POSTPRE_CNCT008SoapClient(bulkApiBinding, bulkApiAdres);
            return client;
        }

    }

    public class FastApiResult
    {
        public FastApiResultSet ResultSet { get; set; }

        public List<FastApiResulItem> ResultList { get; set; }

    }
    public class FastApiResultSet
    {
        public int Code { get; set; }

        public string Description { get; set; }
    }

    public class FastApiResulItem
    {
        public string SmsRefId { get; set; }

        public int Status { get; set; }

        public int ErrorCode { get; set; }

        public string DeliveryDate { get; set; }
    }

    public enum ResponseType : int
    {
        BaseMode = 0,
        BasicMode = 1,
        XmlMode = 2,
        JsonMode = 3
    }
}





