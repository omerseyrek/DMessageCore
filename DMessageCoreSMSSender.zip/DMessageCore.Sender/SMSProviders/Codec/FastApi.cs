using Newtonsoft.Json;
using System;
using System.Data;
using System.Linq;
using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.ServiceLayer;

namespace DMessageCore.Sender.Codec
{
    public class FastApi : ISMSProvider
    {
        public TrialResult Send(SMSQueItem item)
        {

            string smsOriginator = item.SMSRequest.Originator;
            string HeaderCode = item.SMSProvider.SRCMSISDN;

            if (Common.IsAbroad(item.SMSRequest.PhoneNumber))
            {
                smsOriginator = item.SMSProvider.SRCMSISDN_FRGN;
                HeaderCode = item.SMSProvider.SRCMSISDN_FRGN;

                if (item.SMSRequest.PhoneNumber.StartsWith("00") == false)
                {
                    item.SMSRequest.PhoneNumber = "00" + item.SMSRequest.PhoneNumber; //34664146489 yerine 0034664146489 oalrak gönderilmelidir
                }
            }

            FastApiSoapClient client = CodecApiFactory.CreateFastApiClient(item.SMSProvider);
            var result = "";

            try
            {
                var awaiter = client.SendSmsAsync(item.SMSProvider.AgentUserName, item.SMSProvider.AgentPassword, smsOriginator, item.SMSRequest.PhoneNumber, item.SMSRequest.Message, "", false, HeaderCode, (int)ResponseType.JsonMode, null);
                result = awaiter.Result;
            }
            catch (System.Exception ex)
            {
                return new TrialResult()
                {
                    TrialSucces = false,
                    ErrorMessage = $"{Common.CodecFastApiCallFailureText} : {ex.Message}",
                    ErrorCode = Common.CodecFastApiCallFailure,
                    ProviderResponse = result
                };
            }

            FastApiResult apiResult;
            try
            {
                apiResult = JsonConvert.DeserializeObject<FastApiResult>(result);
            }
            catch(System.Exception ex)
            {
                return new TrialResult()
                {
                    TrialSucces = false,
                    ErrorMessage = $"{Common.CodecDeserializationFailureResultText} : {ex.Message}",
                    ErrorCode = Common.CodecDeserializationFailureResult,
                    ProviderResponse = result
                };
            }

            if (apiResult.ResultSet.Code == 0 && apiResult.ResultList.Count > 0)
            {
                var codecProviderResponses =  apiResult.ResultList.Select(p => new { ResponseValue = $"{p.SmsRefId}-{p.Status}" });
                return new TrialResult()
                {
                    TrialSucces = false,
                    ErrorMessage = "",
                    ErrorCode = "0",
                    ProviderResponse = string.Join('|', codecProviderResponses.Select(p => p.ResponseValue).ToList())

                };
            }

            return new TrialResult()
            {
                TrialSucces = false,
                ErrorMessage = apiResult.ResultSet.Code.ToString(),
                ErrorCode = apiResult.ResultSet.Description,
                ProviderResponse = string.Empty
            };
        }
    }
}
