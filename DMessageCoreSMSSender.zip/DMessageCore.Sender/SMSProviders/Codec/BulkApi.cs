
using System;
using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.ServiceLayer;
using seagull = DMessageCore.Sender.seagull_SOAP_API_POSTPRE_CNCT008SoapClient;

namespace DMessageCore.Sender.Codec
{
    public class BulkApi : ISMSProvider
    {
        public TrialResult Send(SMSQueItem item)
        {
            string smsOriginator = item.SMSRequest.Originator;
            string HeaderCode = item.SMSProvider.MSGCODE;

            if (Common.IsAbroad(item.SMSRequest.PhoneNumber))
            {
                smsOriginator = item.SMSProvider.SRCMSISDN_FRGN;
                HeaderCode = item.SMSProvider.MSGCODE_FRGN;

                if (item.SMSRequest.PhoneNumber.StartsWith("00") == false)
                {
                    item.SMSRequest.PhoneNumber = "00" + item.SMSRequest.PhoneNumber; //34664146489 yerine 0034664146489 oalrak gönderilmelidir
                }
            }

            var result = CallSendSMS(item);

            if (result == "-100")
            {
                //do the register job...
                return new TrialResult()
                {
                    TrialSucces = false,
                    ErrorMessage = "invalid codec session",
                    ErrorCode = "1006",
                    ProviderResponse = result
                };
            }

            if (result.Length == 36)
            {
                return new TrialResult()
                {
                    TrialSucces = true,
                    ErrorMessage = string.Empty,
                    ErrorCode =  string.Empty,
                    ProviderResponse = result
                };
            }

            string resultInfo = GetResultText(result);

            return new TrialResult()
            {
                TrialSucces = false,
                ErrorMessage = $"Code : {result} | Description : {resultInfo}",
                ErrorCode = "1007",
                ProviderResponse = result
            };
        }


        private string CallSendSMS(SMSQueItem item)
        {
            try
            {
                bool firstTrial = (item.TrialResults?.Count ?? 0) == 0;
                seagull client = CodecApiFactory.CreateBulkApiClient(item.SMSProvider, !firstTrial);

                if (Common.HasTurkischChars(item.SMSRequest.Message))
                {
                    var resultTr = client.SendSMS_Single_TRAsync(item.SMSProvider.AgentUserName,
                                                  item.SMSProvider.AgentPassword,
                                                  item.SMSProvider.MSGCODE,

                                                  item.SMSRequest.Originator,
                                                  item.SMSRequest.PhoneNumber,
                                                  item.SMSRequest.Message,
                                                  item.SMSRequest.ExternalId,

                                                  DateTime.Now,
                                                  DateTime.Now.AddMinutes(1710),
                                                  RequestSource.Custom).Result;
                    return resultTr;

                }
                else
                {
                    var result = client.SendSMS_SingleAsync(item.SMSProvider.AgentUserName,
                                                     item.SMSProvider.AgentPassword,
                                                     item.SMSProvider.MSGCODE,

                                                     item.SMSRequest.Originator,
                                                     item.SMSRequest.PhoneNumber,
                                                     item.SMSRequest.Message,
                                                     item.SMSRequest.ExternalId,

                                                     DateTime.Now,
                                                     DateTime.Now.AddMinutes(1710),

                                                      RequestSource.Custom).Result;
                    return result;
                }
            }
            catch (System.Exception ex)
            {
                return ex.Message;
            }
        }


        public static string GetResultText(string result)
        {
            string resultInfo = string.Empty;
            switch (result)
            {
                case "-1":
                    resultInfo = "Kullanıcı bilgileri eksik veya hatalı";
                    break;

                case "-10":
                    resultInfo = "Kullanıcı bilgileri eksik veya hatalı";
                    break;

                case "-14":
                    resultInfo = "Henüz rapor dosyası oluşturulmamış";
                    break;

                case "-21":
                    resultInfo = "Hesaba ait günlük limit yetersiz(bkz: Ekler – Gizli Limit)";
                    break;

                case "-22":
                    resultInfo = "Hesaba ait aylık limit yetersiz(bkz: Ekler – Gizli Limit)";
                    break;

                case "-23":
                    resultInfo = "Kullanıcıya ait günlük limit yetersiz(bkz: Ekler – Gizli Limit)";
                    break;

                case "-24":
                    resultInfo = "Kullanıcıya ait aylık limit yetersiz(bkz: Ekler – Gizli Limit)";
                    break;

                case "-25":
                    resultInfo = "IP tanımlı değil";
                    break;

                case "-26":
                    resultInfo = "Geçersiz pSender";
                    break;

                case "-32":
                    resultInfo = "Yetersiz Bakiye";
                    break;

                case "-45":
                    resultInfo = "pContent içerisinde pMsisdn parametresinde belirtilmiş numara sayısı kadar mesaj ~karakteri ile ayrışmış şekilde girilmelidir.";
                    break;

                case "-100":
                    resultInfo = "Geçersiz pSessionId";
                    break;

                default:
                    resultInfo = result;
                    break;
            }

            return resultInfo;
        }

    }
}