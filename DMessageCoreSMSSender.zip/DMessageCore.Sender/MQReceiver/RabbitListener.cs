
using System.Text;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using DMessageCoreCommon.Model;
using DMessageCore.Sender;
using System.Collections.Generic;
using DMessageCoreCommon.MQLayer;
using DMessageCoreSMSSender.ServiceLayer;
using DMessageCore.Sender.EMailProviders;
using DMessageReceiver.ServiceLayer;
using System;
using DMessageCore.Logging;
using DMessageCore.Logging.Models;
using DMessageCore.Logging.Common;

namespace DMessageCoreSMSSender
{

    public class RabbitListener
    {
        ConnectionFactory factory { get; set; }
        IConnection connection { get; set; }
        IModel channel { get; set; }
        ITokenService tokenService = null;
        ICustomLogging<LogModel> _logger;

        public RabbitListener(ITokenService tokenService,  ICustomLogging<LogModel> logger)
        {
            this.tokenService = tokenService;
            this._logger = logger;
        }

        public void Register()
        {
            registerEmail();
            registerSMS();
            registerFastSMS();
            registerNotification();
        }


        public void Deregister()
        {
            this.connection.Close();
        }

        private void registerNotification()
        {
            connection = RabbitHelper.GetConnection;
            channel = connection.CreateModel();
            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (model, ea) =>
            {
                var content = Encoding.UTF8.GetString(ea.Body.ToArray());
                NotificationQueItem notty = JsonConvert.DeserializeObject<NotificationQueItem>(content);
                _logger.AddLog(new LogModel(notty.Id, ProcessConstants.SendNotification, ProcessMessages.NotificationPushProcessStarted, content));
                PushNotification(notty);
            };
            channel.BasicConsume(queue: QueNames.NotificationPushExchangeQue, autoAck: true, consumer: consumer);
        }


        private void registerSMS()
        {
            connection = RabbitHelper.GetConnection;
            channel = connection.CreateModel();
            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (model, ea) =>
            {
                var content = Encoding.UTF8.GetString(ea.Body.ToArray());
                SMSQueItem sms = JsonConvert.DeserializeObject<SMSQueItem>(content);
                sms.IsFastApi = false;

                _logger.AddLog(new LogModel(sms.Id, ProcessConstants.SendSMS, ProcessMessages.SmsPushProcessStarted, content));
                PushSMS(sms);
            };
            channel.BasicConsume(queue: QueNames.SMSPushExchangeQue, autoAck: true, consumer: consumer);
        }

        private void registerFastSMS()
        {
            connection = RabbitHelper.GetConnection;
            channel = connection.CreateModel();
            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (model, ea) =>
            {
                var content = Encoding.UTF8.GetString(ea.Body.ToArray());
                SMSQueItem sms = JsonConvert.DeserializeObject<SMSQueItem>(content);
                sms.IsFastApi = true;

                _logger.AddLog(new LogModel(sms.Id, ProcessConstants.SendSMS, ProcessMessages.SmsShotPushProcessStarted, content));
                PushSMS(sms);
            };
            channel.BasicConsume(queue: QueNames.SMSFastPushExchangeQue, autoAck: true, consumer: consumer);
        }

        private void PushSMS(SMSQueItem record)
        {
            try
            {
                if (record.TrialResults == null)
                {
                    record.TrialResults = new List<TrialResult>();
                }
                ISMSProvider smsProvider = SMSProviderFactory.GetSMSProvider(record, tokenService);
                TrialResult result = smsProvider.Send(record);
                record.TrialResults.Add(result);
                _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendSMS, ProcessMessages.FirstSmsTrial, JsonConvert.SerializeObject(result)));

                if (result.ErrorMessage == Common.TurkcellInvalidSessionText)
                {
                    result = smsProvider.Send(record);
                    record.TrialResults.Add(result);
                    _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendSMS, ProcessMessages.SecondSmsTrial, JsonConvert.SerializeObject(result)));
                    if (result.ErrorMessage == Common.TurkcellInvalidSessionText)
                    {
                        result = smsProvider.Send(record);
                        record.TrialResults.Add(result);
                        _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendSMS, ProcessMessages.ThirdSmsTrial, JsonConvert.SerializeObject(result)));
                    }
                }
                IMQManager<SMSQueItem> mqManager = new PushMQResultManager<SMSQueItem>();
                mqManager.PushSMSResult(record);
                _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendSMS, ProcessMessages.PushSMSResultToMessageQue, ""));
            }
            catch(System.Exception ex)
            {
                _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendSMS, ProcessMessages.PushSMSException, $"{ex.Message} - {ex.InnerException}" ));
            }
        }


        private void registerEmail()
        {
            connection = RabbitHelper.GetConnection;
            channel = connection.CreateModel();
            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (model, ea) =>
            {
                var content = Encoding.UTF8.GetString(ea.Body.ToArray());
                EMailQueItem email = JsonConvert.DeserializeObject<EMailQueItem>(content);
                email.WithType = false;
                _logger.AddLog(new LogModel(email.Id, ProcessConstants.SendEmail, ProcessMessages.EmailPushProcessStarted, content));
                PushEmail(email);
            };
            channel.BasicConsume(queue: QueNames.EMailPushExchangeQue, autoAck: true, consumer: consumer);
        }


        private void PushEmail(EMailQueItem record)
        {
            try
            {
                if (record.TrialResults == null)
                {
                    record.TrialResults = new List<TrialResult>();
                }
                IEMailProvider emailProvider = EMailProviderFactory.GetEMailProvider(record, tokenService);
                TrialResult result = emailProvider.Send(record);
                record.TrialResults.Add(result);
                _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendEmail, ProcessMessages.FirstEmailTrial, JsonConvert.SerializeObject(result)));

                if (result.ErrorMessage == Common.TurkcellInvalidSessionText)
                {
                    result = emailProvider.Send(record);
                    record.TrialResults.Add(result);
                    _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendEmail, ProcessMessages.SecondEmailTrial, JsonConvert.SerializeObject(result)));
                    if (result.ErrorMessage == Common.TurkcellInvalidSessionText)
                    {
                        result = emailProvider.Send(record);
                        record.TrialResults.Add(result);
                        _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendEmail, ProcessMessages.ThirdEmailTrial, JsonConvert.SerializeObject(result)));
                    }
                }
                IMQManager<EMailQueItem> mqManager = new PushMQResultManager<EMailQueItem>();
                mqManager.PushEmailResult(record);
                _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendEmail, ProcessMessages.PushEmailResultToMessageQue, ""));
            }
            catch (System.Exception ex)
            {
                _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendEmail, ProcessMessages.PushEmailException, $"{ex.Message} - {ex.InnerException}"));
            }
        }


        private void PushNotification(NotificationQueItem record)
        {
            TrialResult result = new TrialResult();

            try
            {
                if (record.TrialResults == null)
                {
                    record.TrialResults = new List<TrialResult>();
                }
                INotificationProvider notificationProvider = NotificationProviderFactory.GetNotificationProvider(record, tokenService);
                result  = notificationProvider.Send(record);
                record.TrialResults.Add(result);

                IMQManager<NotificationQueItem> mqManager = new PushMQResultManager<NotificationQueItem>();
                mqManager.PushNotificationResult(record);
                _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendNotification, ProcessMessages.PushNotificationResultToMessageQue, ""));
            }
            catch (System.Exception ex)
            {
                _logger.AddLog(new LogModel(record.Id, ProcessConstants.SendNotification, ProcessMessages.PushNotificationException, $"{ex.Message} - {ex.InnerException}"));

                result.TrialSucces = false;
                result.ErrorCode = ex.Message;
                result.ErrorMessage = ex.InnerException?.ToString() ?? string.Empty;
            }

        }

    }
}

