
using Microsoft.Extensions.Configuration;

namespace DMessageCoreSMSSender
{
    public static class ConfigurationProxy
    {
        private static IConfiguration configuration;

        public static IConfiguration Configuration { get => configuration; set => configuration = value; }
    }
}