using System;
using Microsoft.Extensions.Configuration;
using RabbitMQ.Client;

namespace DMessageCoreSMSSender {

    public class RabbitHelper {
        static Lazy<IConnection> _connection = new Lazy<IConnection> (CreateConnection);
        static Lazy<IConnectionFactory> _connectionFactory = new Lazy<IConnectionFactory> (CreateConnectionFactory);

        public static IConnection GetConnection => _connection.Value;

        public static IConnectionFactory GetConnectionFactory => _connectionFactory.Value;


        private static IConnection CreateConnection () 
        {
            var connection = _connectionFactory.Value.CreateConnection();
            return connection;          
        }

        private static IConnectionFactory CreateConnectionFactory () {

            var factory = new ConnectionFactory () {
                HostName = ConfigurationProxy.Configuration.GetValue<string> ("MessageOueSettings:HostName"),
                Port = Protocols.DefaultProtocol.DefaultPort,
                UserName = ConfigurationProxy.Configuration.GetValue<string> ("MessageOueSettings:UserName"),
                Password = ConfigurationProxy.Configuration.GetValue<string> ("MessageOueSettings:Password"),
                VirtualHost = ConfigurationProxy.Configuration.GetValue<string> ("MessageOueSettings:VirtualHost"),
                ContinuationTimeout = new TimeSpan (0, 0, 0, ConfigurationProxy.Configuration.GetValue<int> ("MessageOueSettings:ContinuationTimeout"))
            };

            return factory;
        }

    }
}