﻿using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.ServiceLayer;


namespace DMessageCore.Sender.EMailProviders
{
    public static class EMailProviderFactory
    {
        public static IEMailProvider GetEMailProvider(EMailQueItem item, ITokenService tokenService)
        {
            if (item.EMailProvider.AgentType == AgentType.EuroMessage)
            {
                return new EuroMessageEMailProvider(tokenService);
            }
           
            else return null;
        }
    }
}
