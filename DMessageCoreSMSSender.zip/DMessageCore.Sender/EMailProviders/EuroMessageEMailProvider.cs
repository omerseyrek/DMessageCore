﻿
using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.ServiceLayer;
using EuroMessageAuth;
using EuroMessageSMS;
using System;
using System.ServiceModel;

namespace DMessageCore.Sender.EMailProviders
{
    public class EuroMessageEMailProvider : IEMailProvider
    {
        private ITokenService _tokenService { get; }

        public EuroMessageEMailProvider(ITokenService tokenService)
        {
            _tokenService = tokenService;
        }

        public TrialResult Send(EMailQueItem item)
        {
            TrialResult trialResult = null;

            if ((item.TrialResults?.Count ?? 0) >= 3)
            {
                trialResult = new TrialResult();
                trialResult.ErrorCode = Common.TrialResultExceeded;
                trialResult.ErrorMessage = Common.TrialResultExceededText;
                trialResult.TrialSucces = false;
                return trialResult;
            }

            if ((item.TrialResults?.Count ?? 0) == 0 && !string.IsNullOrEmpty(item.EMailProvider?.Token ?? string.Empty))
            {
                return SendToProvider(item);
            }

            RegisterTokenModel tokenModel = new RegisterTokenModel()
            {
                BusinesUnitId = item.BussinesClientId,
                AgentType = item.EMailProvider.AgentType,
                AgentUser = item.EMailProvider.AgentUserName
            };

            RegisterTokenModel tokenModelReult = _tokenService.GetTokenRecentToken(tokenModel);
            if (tokenModelReult != null && (item.TrialResults?.Count ?? 0) < 3)
            {
                item.EMailProvider.Token = tokenModelReult.Token;
            }
            else
            {
                trialResult = new TrialResult();
                Action<ITokenField> registerAction = Register;
                _tokenService.RegisterToken(registerAction, item, trialResult);
                if (!String.IsNullOrEmpty(trialResult.ErrorCode)) //register işlemi başarısız ise..
                {
                    return trialResult;
                }
            }

            trialResult = SendToProvider(item);
            return trialResult;


        }



        private TrialResult SendToProvider(EMailQueItem item)
        {
            TrialResult trialResult = new TrialResult();

            var binding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport);
            var endpoint = new EndpointAddress(new Uri(item.EMailProvider.PostUrl));
            var channelFactory = new ChannelFactory<PostSoap>(binding, endpoint);
            var serviceClient = channelFactory.CreateChannel();


            if (string.IsNullOrEmpty(item.EMailRequest.FromName) && string.IsNullOrEmpty(item.EMailProvider.FromName) == false)
            {
                item.EMailRequest.FromName = item.EMailProvider.FromName;
            }

            if (string.IsNullOrEmpty(item.EMailRequest.FromAddress) && string.IsNullOrEmpty(item.EMailProvider.FromAddres) == false)
            {
                item.EMailRequest.FromAddress = item.EMailProvider.FromAddres;
            }

            if (string.IsNullOrEmpty(item.EMailRequest.ReplayAddress) && string.IsNullOrEmpty(item.EMailProvider.FromAddres) == false)
            {
                item.EMailRequest.ReplayAddress = item.EMailProvider.ReplayAddres;
            }


            var responseCode = "";
            var responseMessage = "";
            var responsePacketId = "";

            if (item.WithType)
            {
                PostHtmlWithTypeRequestBody bodyWithType = new PostHtmlWithTypeRequestBody();
                bodyWithType.ServiceTicket = item.EMailProvider.Token;
                bodyWithType.FromAddress = item.EMailRequest.FromAddress;
                bodyWithType.FromName = item.EMailRequest.FromName;
                bodyWithType.ReplyAddress = item.EMailRequest.ReplayAddress;
                bodyWithType.Subject = item.EMailRequest.Subject;
                bodyWithType.HtmlBody = item.EMailRequest.HtmlBody;
                bodyWithType.Charset = item.EMailRequest.CharSet;
                bodyWithType.ToEmailAddress = item.EMailRequest.ToEmailAddress;
                bodyWithType.ToName = item.EMailRequest.ToName;
                bodyWithType.Attachments = null;  //todo : manage attachments...
                PostHtmlWithTypeRequest requestWithType = new PostHtmlWithTypeRequest(bodyWithType);

                var postResWithType = serviceClient.PostHtmlWithType(requestWithType);

                responseCode = postResWithType.Body.PostHtmlWithTypeResult.Code;
                responseMessage = postResWithType.Body.PostHtmlWithTypeResult.Message;
                responsePacketId = postResWithType.Body.PostHtmlWithTypeResult.PostID;

            }
            else
            {
                PostHtmlRequestBody body = new PostHtmlRequestBody();
                body.ServiceTicket = item.EMailProvider.Token;
                body.FromAddress = item.EMailRequest.FromAddress;
                body.FromName = item.EMailRequest.FromName;
                body.ReplyAddress = item.EMailRequest.ReplayAddress;
                body.Subject = item.EMailRequest.Subject;
                body.HtmlBody = item.EMailRequest.HtmlBody;
                body.Charset = item.EMailRequest.CharSet;
                body.ToEmailAddress = item.EMailRequest.ToEmailAddress;
                body.ToName = item.EMailRequest.ToName;
                body.Attachments = null;  //todo : manage attachments...
                PostHtmlRequest request = new PostHtmlRequest(body);

                var postRes = serviceClient.PostHtml(request);

                responseCode = postRes.Body.PostHtmlResult.Code;
                responseMessage = postRes.Body.PostHtmlResult.Message;
                responsePacketId = postRes.Body.PostHtmlResult.PostID;
            }



            trialResult.Processdate = DateTime.UtcNow;

            if (string.IsNullOrEmpty(responsePacketId))
            {
                if (responseCode == "00")
                {
                    trialResult.TrialSucces = true;
                    trialResult.ErrorMessage = "";
                    trialResult.ProviderResponse = responsePacketId;
                }
                else if (responseCode == "9998")
                {
                    trialResult.ErrorCode = Common.EuroMessageInvalidSessionCode;
                    trialResult.TrialSucces = false;
                    trialResult.ErrorMessage = Common.EuroMessageInvalidSessionCodeText;
                }
                else
                {
                    trialResult.ErrorCode = Common.DMessageCoreGeneralException;
                    trialResult.TrialSucces = false;
                    trialResult.ErrorMessage = responseMessage;
                }
                
                return trialResult;
            }
            
            trialResult.ErrorCode = "";
            trialResult.TrialSucces = true;
            trialResult.ErrorMessage = "";
            trialResult.ProviderResponse = responsePacketId;
            return trialResult;
            
        }


        private void Register(ITokenField itemProxy)
        {
            EMailQueItem item = (EMailQueItem)itemProxy;
            var binding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport);
            var endpoint = new EndpointAddress(new Uri(item.EMailProvider.RegisterUrl));
            var channelFactory = new ChannelFactory<EuroMessageAuth.AuthSoap>(binding, endpoint);
            var serviceClient = channelFactory.CreateChannel();

            EmAuthResult authResult = serviceClient.LoginAsync(itemProxy.AgentNameProxy, itemProxy.AgentPasswordProxy).Result;

            if (authResult.Code == "00")
            {
                item.EMailProvider.Token = authResult.ServiceTicket;
            }
            else
            {
                item.EMailProvider.Token = Common.InvalidSessionToken + " - " + authResult.Code + " - " + authResult.Message;
            }
        }

    }
}
