﻿
namespace DMessageCore.Sender
{
    using DMessageCoreCommon.Model;
    public interface IEMailProvider
    {
        TrialResult Send(EMailQueItem item);
    }
}

