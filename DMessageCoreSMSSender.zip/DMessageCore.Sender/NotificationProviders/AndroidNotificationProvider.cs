﻿using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.ServiceLayer;
using DMessageReceiver.ServiceLayer;
using Newtonsoft.Json.Linq;
using PushSharp.Common;
using PushSharp.Google;
using System.Collections.Generic;

namespace DMessageCore.Sender
{
    internal class AndroidNotificationProvider : INotificationProvider
    {
        private ITokenService tokenService;

        public AndroidNotificationProvider(ITokenService tokenService)
        {
            this.tokenService = tokenService;
        }

        public TrialResult Send(NotificationQueItem item)
        {
            TrialResult trialResult = new TrialResult();
            var config = new GcmConfiguration(item.MobileApp.Android.ApiKey);

            config.GcmUrl = "https://fcm.googleapis.com/fcm/send";
            var gcmBroker = new GcmServiceBroker(config);

            gcmBroker.OnNotificationFailed += (notification, aggregateEx) =>
            {
                aggregateEx.Handle(ex =>
                {
                    if (ex is GcmNotificationException)
                    {
                        var notificationException = (GcmNotificationException)ex;
                        var gcmNotification = notificationException.Notification;
                        var description = notificationException.Description;

                        trialResult.ErrorCode = ((GcmNotificationException)ex).Message;
                        trialResult.ErrorMessage = ((GcmNotificationException)ex).Description;

                    }
                    else if (ex is GcmMulticastResultException)
                    {
                        var multicastException = (GcmMulticastResultException)ex;

                        foreach (var succeededNotification in multicastException.Succeeded)
                        {
                            trialResult.TrialSucces = true;
                            trialResult.ProviderResponse += $"{succeededNotification.RegistrationIds[0]} - {succeededNotification.Data.ToString()} :";
                        }

                        foreach (var failedKvp in multicastException.Failed)
                        {
                            trialResult.TrialSucces = false;
                            trialResult.ErrorCode = "GcmMulticastResultException";
                            trialResult.ErrorMessage += $"{failedKvp.Value.Message} - {notification.Data.ToString()} :";
                        }

                    }
                    else if (ex is DeviceSubscriptionExpiredException)
                    {
                        var expiredException = (DeviceSubscriptionExpiredException)ex;
                        trialResult.TrialSucces = false;
                        trialResult.ErrorCode = "DeviceSubscriptionExpiredException 8";
                        trialResult.ErrorMessage += $" {notification.Data.ToString()} newId : {(expiredException.NewSubscriptionId ?? "")}     OldId : {expiredException.OldSubscriptionId}";

                    }
                    else if (ex is RetryAfterException)
                    {
                        var retryException = (RetryAfterException)ex;
                        trialResult.TrialSucces = false;
                        trialResult.ErrorCode = "RetryAfterException 6";
                        trialResult.ErrorMessage += $" GCM Rate Limited, don't send more until after {retryException.RetryAfterUtc.ToLongDateString()} -  { notification.Data.ToString()}";
                    }
                    else
                    {
                        trialResult.ErrorCode = "UnknownReason 6";
                        trialResult.ErrorMessage += $" GCM Notification Failed for some unknown reason { notification.Data.ToString()}";
                    }

                    return true;
                });
            };

            gcmBroker.OnNotificationSucceeded += (notification) =>
            {
                trialResult.TrialSucces = true;
                trialResult.ProviderResponse += $"{notification.RegistrationIds[0]} - {notification.Data.ToString()} :";
            };

            gcmBroker.Start();

            gcmBroker.QueueNotification(new GcmNotification
            {
                RegistrationIds = new List<string> 
                {
                    item.NotificationRequest.ClientId
                },
                Data = JObject.Parse(item.MobileApp.Android.AndroidJson.Replace("crmsubject", item.NotificationRequest.Subject).Replace("crmmessage", item.NotificationRequest.Message))
            });

            gcmBroker.Stop();

            return trialResult;
        }
    }
}