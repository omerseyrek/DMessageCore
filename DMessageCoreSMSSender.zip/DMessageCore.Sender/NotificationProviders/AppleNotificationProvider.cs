﻿using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.ServiceLayer;
using DMessageReceiver.ServiceLayer;
using PushSharp.Apple;
using System.Text;

namespace DMessageCore.Sender
{
    internal class AppleNotificationProvider : INotificationProvider
    {
        private ITokenService tokenService;

        public AppleNotificationProvider(ITokenService tokenService)
        {
            this.tokenService = tokenService;
        }

        public TrialResult Send(NotificationQueItem item)
        {
            TrialResult trialResult = new TrialResult();

            //string certificateFile = "MIIM7wIBAzCCDLYGCSqGSIb3DQEHAaCCDKcEggyjMIIMnzCCBy8GCSqGSIb3DQEHBqCCByAwggccAgEAMIIHFQYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQIAa5cqj4R9fMCAggAgIIG6Dr8yYYc4B1UZsTXBAFhE + bMOAtdedZurBL5 / OTeKx2ANQNi1mYVVA4FUiTRLBKjAmcGgYht5j01Uojhnec60hANCFNCtabiVFtx2nSZXbe541wTOp2c144O6QzB73 / 8H + Du2qdrRo8zgvqHOA8TMAPfWg + MmnpO6CJMF8knhS0ZdUEKIPFuc7bdxFYwJeH / ksO6vz0ZSIHRJcVHOsfi9zB6Vgr7J5CEO1p1NDu0YJbnwkLIwdaL3pdaMUhuf / u5 / aOZlnBwXdaOwyiOUePmR7rTsW / JhBwP3puiFirc41MU + eR11xv5S70 / eGFyrb / l2UO0bCqjqiX33zrmewhp76Dc1ZiIL5 + ko2 / XMAHNc2updnU + IMeX + xG9GOMvatC6w4ZJP9nXqN8Kxg9oI9JRUyFUXAy5LX9CCstv2eaL69ESIRF / aOU6AJ7EsTf3LtIbFIdZILGKngBJNmIHmEJlvS0ffaCZiFIjrDlInYAS3YyIwBnO1YXJB + 3zD33 + DtGTqk75waDkOeQy6njam / RYt3vlX / HOEe6OKJFwfJIHljjAltmNh45y2NUJlNrnHk14ouVxoYTUvZgxkL4ZDZeev4fBCeFsPGWlzwBuD5Rppfnaaibv9K0ZkLatGExigkYyM0X + Tn3FmRhnfCIbCpfKylfDq1jCrO6bgRNnWXXwVp68ORA8l1ZWcl0Ev9CBuVxe / rA94sNd66JZhOKpcPLdyQNTUlY7aHaASiYFN / GZzKfjqnlWBafMH3PdIHznxHxJgBvkwW5YIC + EjLH + NBhS7yFsv37fb2OK3RTA0AgEaSdRk8AZS1lzVYyx8DC7Rfoqb + KHX5yIXDH0Hd6Q0T9Q3oJMOOBMhCnPB3wSWHclEgeHBMB39ifCeRwFDZQDFqNg3EDEpi9dMNpEimmvO2s3LnoBEtT50UeW4tGT7myiF29tk / B9OsHEJbbTcLne2YXhBGVN9RvSwYqrEYtBQfzgcDu53we + tWAIKe0lX / RT7z7q90mvg2Ty3AsyoMfvsf + r21DieYxHOBM0BVxbA5bbibjQglIy13BhLtIokGFgZeKx6s8pD953petjM8FyyO8wC + eyPxcdgmcM9o / JqWEM0KxYAZLhlzlGjvEUg3jwRHlDTytVEzQbFn3t384ZXmvtoElgV1jhI14QGWkNVVsN3zLiKiOi2WX6oR / yvGSChI4DlMndZAKwnLel6WTg4VloJMFeA3I / 92GQL3JrZ5uFAkDBmRtbpvXjwfwy3CU3y8COoagTahyjxwiy3trz / GxI / 1aZRcU + ydPx8zSRhv4g5bTEuGnivGL2PmKj21ZLY7Tk938hvw2nGGoJkAduXZTglUpfX98qpu8gBYeOcfFjS1mG3tdDss / Vh + Zt / VBZbHjS + X / L6Dc0tbXtus4JHuXLKOK0G0k3B6D + xSAOZlkU0xTdy9BB5Co4UtUWfTgUWOCNEPheZFMu5JyyHc4PXyoqxEf0wYSnSqQHLTI6EHStVl6txqClIRGuyg1Lq / eWwvckj1DdcGIp2YvtYxK4jdVnAm1Ts0Bc8HmN96P8GOl7OY0tnlmt / L88JEBrxStMkRQ4qnwm0GrAbn8BeLZO6D4TcAV4VwstKIpPUZ0gE4bBcz27Ae2eee6y + siPiUYVJYrL41RN9EYic555QxG6VD35ktZaGeMk6TYFKy3xdf7 + DvU9NEAxoChPvLFrdtVOI5SpMpoEgPS + y7qU92dOW5sYqxkT8Y + tLhL1NKX3CT3GJ3U3xEar6UsRI7AMRi0Qgt9GRH7i + ZA5BdeZ3zwKjsRbsLa51OwBuQSWc / kToelCqYu3oIDS4vnjMNd0SQkEhSoHeyi6FGgTYFTVvORFLDXjJz0iYMBtfQtenyeYXlrpzy0r3h3HMk13vNdkIM + Asu1JAXye / JR8unD3daKeALhEYyblKyzXSqxopl3zI7NHsC3UyZ / 5gmo / ILEet1NgMtgJ6HLX + PPXUufGC + moWq1SH + rqoeBegUV40SLQLkfPd2iSYMrlcRhK9I4JQbYdOraVyxoUKY0sntBZ24oCxaLozxCXru8HrQn5j3FOJxKeF6 / bVzU4VyFcEppgNqtrUPLVwoNQT9IINqwuNMn911CrzhZiQJuMn1dKsdvmOE8PnB4iYsxzuCeRTy8tvtpk1Ku9PALJLqOnHZNaO8IiBnlWuBl1gDLJsntso4rO6wG0xfCfdNNeprjDwCzwdPZxeeiD3quhI7qi6zaoOQm0fnkeID +/ tUHBNVcFS4w / ahOwqxwR1NRfVQ1Xp4hF07MtZ1P1wPjP7BirMsWZ3UjgC0EQH + K7hs6KwFIyrZ8889TAME75zH8e89TmUDs1gltlV0f14BHriI / mHx8wggVoBgkqhkiG9w0BBwGgggVZBIIFVTCCBVEwggVNBgsqhkiG9w0BDAoBAqCCBO4wggTqMBwGCiqGSIb3DQEMAQMwDgQIYCLu9Lm6ZuYCAggABIIEyMivMtc1UTOCVmB9JwHXhWAg7hakrGTeFj6PMN6iHquUFrKrwGa8bn8DgrcZhE3dOMTdoHqYX9nefBUQALsxV5BI2j + GzXqdbaxBhJEbgOSNp7i + VEl4SdSGYMZxopfNZPnDirkKaYIfnVHQDX4pcR9aWOqBM7nFHSVG + U2HnBenwumCdZKSXY80tEQthV + lXRPrm5LWeatyUfHGD1qfUJtnw / 7FQASiiA6MHFcos3SO8ZvxXddp4vD2kIO4k2Gi5Tr3OhtAlmq6eB8S2qY6iiDaShqPX + AIFmXeWzI5PDI7vqvbkDp1z6lyL8SHZ6vRxo79oq5dF4py3yOox7 / gmINbmOl0uwjDyExC9eFyjRz3eQVgZB3sZnTfBF8XlhifpFYy + mQ3XSeplQsHgsG49sqP28ZNxkDYOxUszyL74nfvhzCMI4OVx / fz4Zd8RM4FGwySzVDZBZ61SXKI + X9ST / zn9jPdEmXxVdWFhGNH01EKYAbVNbDme96HHeFq8R3G6VtA / wQOxACB9DxGjJVFLk / w + 0zsp0G10xRsbkrdTL5j0P16nNc0 + IEhbjB5AgHZ2SCPCq5h98oswYGizIkRqL13JVdcdi3 + T1YAEDrLhKNxUJnK614LR10ZpKvVRTSRGte5hB7nv5vzHOcpQhbunJqCzjskX7n3FvImESPJma7XROf8uhTB + kfrzSPi6XKtrOWEVv + cacuY00JkGlzD6F + VxSTYB3t2JncofgQNpWPOxjgHM7YQedCJVpOH9 + ShqGEYUvbvOl + CT47HSESxId7SFIKjyqkbazhncsBsH06GvdEoRrT4LLw4B8syp4y1vRrQ4FHe7vRENX9t7lcZPBgB4phuxrxeRCFs8ml4L8AagZDEMirSsUt1qwxYbPGgXrwcH / CVzEa0SQUNhGvU4sMihzWa / fVw2CIKlTUaeKbycJlSBYNZvrw8BPTWgkadMNOKn0h7oW + 7TBOtnBBHFk0MHKRrn6gdGou6Q8w2iJpb9DvgZlfaRrHUzaZPiDDgMGVaTCXNue + York7jkA9RUteMrRalZAHXmYd8EBwOJXhK3ztElymHh9Ij6VutiTKKoxdYj82vv20A + ycdWGdVfUG5gtqtOCgjQ7gfrgQ2kizX7r73cRpdG1RPrXhOAAsl2 + Eplse1Gzw2uWDDcnZcc7M7Pu0huf8R1Kq / lTc + TzXCzJJJ2f6AfZzD + iBDs9GlEON6TY//oBj3CVPEuoC2gNQRghA/9JJKGKtyGB3AldhDXx7OAWbTEGOiHWRr0u+dS0BdhjK5l2ULil+tQh4CnhjLpZel6sj937wBSF7oJDK+cCpBxuWH4GgGN3ng4NBk54cI6a0rjouafwWYUmxkXgw7QJtDTMHPlqb0VHl5tvyxp7MRu8tCiSWBVY6DXsw3lckgwOT5sGb76U0+edgWK9BNNuII8TUt1/AYeJ/bMs+wnWdSaycsfwxToVItCBUjFCi0WkrdT2eNKn3Wqhxxu1+zLIZhaXFQa82j/OxU0j/9JyckvHrH1Uv715lQPQviS0PyzGRPoNJE4ID14R4tez8Zsr2QmzLkY7Il+74ibXndSE5/eSy+dcHBCRBU8TFSpCEZisdGc9A+0HtNC8nk2I5Wz8wkcUjDDFMMCUGCSqGSIb3DQEJFDEYHhYAWgB1AGIAaQB6AHUALQBUAGUAYQBtMCMGCSqGSIb3DQEJFTEWBBSHAapRPO2PDTxTQGmjNCYH2xY6lTAwMCEwCQYFKw4DAhoFAAQUI0E0F6ZMdsbfxR6i8TfLeoYJitoECEJYkOahg3OEAgEB";

            //string certificateFile = Encoding.UTF8.GetString(item.MobileApp.IOS.CertificateFile, 0, item.MobileApp.IOS.CertificateFile.Length); ;

            var config = new PushSharp.Apple.ApnsConfiguration(PushSharp.Apple.ApnsConfiguration.ApnsServerEnvironment.Production, item.MobileApp.IOS.CertificateFile, item.MobileApp.IOS.CertificatePassword);
            
            var apnsBroker = new PushSharp.Apple.ApnsServiceBroker(config);

            apnsBroker.OnNotificationFailed += (notification, aggregateEx) =>
            {
                aggregateEx.Handle(notificationException =>
                {
                    trialResult.ErrorCode = "APPLE6";
                    if (notificationException is PushSharp.Apple.ApnsNotificationException)
                    {
                        trialResult.ErrorMessage = $"{notificationException.InnerException.ToString()} -  {notification.Payload.ToString()} - {notificationException.Message}";
                    }
                    else
                    {
                        trialResult.ErrorMessage = $"{notificationException.InnerException.ToString()} -  {notification.Payload.ToString()} - {item.NotificationRequest.ClientId}";
                    }

                    return true;
                });
            };

            apnsBroker.OnNotificationSucceeded += (notification) =>
            {
                trialResult.TrialSucces = true;
                trialResult.ErrorCode = "APPLE7";
                trialResult.ErrorMessage = $"";
            };

            apnsBroker.Start();

            apnsBroker.QueueNotification(new ApnsNotification
            {
                DeviceToken = item.NotificationRequest.ClientId,
                Payload = Newtonsoft.Json.Linq.JObject.Parse("{\"aps\":{\"alert\":\"" + item.NotificationRequest.Message + "\",\"badge\":1,\"sound\":\"default\"}}")
            });

            apnsBroker.Stop();

            return trialResult;
        }
    }
}