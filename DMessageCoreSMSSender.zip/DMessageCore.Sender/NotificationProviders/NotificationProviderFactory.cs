﻿using DMessageCoreCommon.Model;
using DMessageCoreSMSSender.ServiceLayer;
using DMessageReceiver.ServiceLayer;

namespace DMessageCore.Sender
{
    public static class NotificationProviderFactory
    {
        public static INotificationProvider GetNotificationProvider(NotificationQueItem item, ITokenService tokenService)
        {
            if (item.NotificationRequest.AppType == AppType.Android)
            {
                return new AndroidNotificationProvider(tokenService);
            }
            if (item.NotificationRequest.AppType == AppType.IOS)
            {
                return new AppleNotificationProvider(tokenService);
            }
            else return null;
        }
    }
}
