﻿
namespace DMessageCore.Sender
{
    using DMessageCoreCommon.Model;
    using DMessageReceiver.ServiceLayer;

    public interface INotificationProvider
    {
        TrialResult Send(NotificationQueItem item);
    }
}

