﻿using DMessageCore.Logging.ElasticSearch;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DMessageCore.Logging
{

    public static class LogMiddlewareExtension
    {

        public static IApplicationBuilder UseCustomLogging(this IApplicationBuilder builder, IConfiguration configuration = null)
        {
            var services = IServiceCollectionExtension.Instance;            
            services.Configure<ElasticConnectionSettings>(configuration.GetSection("ElasticConnectionSettings"));
            services.AddTransient(typeof(IElasticSearchService<>), typeof(ElasticSearchService<>));
            services.AddSingleton<ElasticClientProvider>();
            return builder.New();
        }

    }

    public sealed class IServiceCollectionExtension
    {
        IServiceCollectionExtension()
        {
        }
        private static readonly object padlock = new object();
        private static ServiceCollection instance = null;
        public static ServiceCollection Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new ServiceCollection();
                    }
                    return instance;
                }
            }
        }
    }
}
