﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging
{
    public enum LogTypes
    {
        Information,
        Warning,
        Error

    }
}
