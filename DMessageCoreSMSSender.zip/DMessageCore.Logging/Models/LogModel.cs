﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging.Models
{
  public class LogModel: IEntityModel
    {
        public LogModel()
        {
            CreateDate = DateTime.Now;
        }

        public LogModel(Guid Id, string processType, string message, String jsonBody)
        {
            Guid = Id;
            ProcessType = processType;
            Message = message;
            JsonBody = jsonBody;
            CreateDate = DateTime.Now;

        }

        public Guid Guid { get; set; }
        public string ProcessType { get; set; }
        public string Message { get; set; }
        public string JsonBody { get; set; }
        public DateTime CreateDate { get; set; }

    }
}
