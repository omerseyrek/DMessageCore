﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging.Models
{
  public  interface IEntityModel
    {
    }
}
