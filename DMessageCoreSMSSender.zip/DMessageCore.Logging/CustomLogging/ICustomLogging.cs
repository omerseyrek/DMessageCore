﻿using DMessageCore.Logging.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging
{
    public interface ICustomLogging<T> where T : class, IEntityModel,new()
    {
        void AddLog(T logModel, LogTypes logType);
        void AddLog(T logModel);
    }
}
