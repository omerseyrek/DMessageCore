﻿using DMessageCore.Logging.ElasticSearch;
using DMessageCore.Logging.Models;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging
{
   public class CustomLogging<T> :ICustomLogging<T> where T : class, IEntityModel,new()
    {

        private  IElasticSearchService<T> _elasticSearchService;
        public CustomLogging()
        {
            Initialize();
        }

        public void AddLog(T LogModel, LogTypes logType)
        {
            throw new NotImplementedException();
        }

        public void AddLog(T logModel)
        {
            _elasticSearchService.CheckExistsAndInsertLog(logModel);
        }

        private void Initialize()
        {
            var services = IServiceCollectionExtension.Instance;
            var provider = services.BuildServiceProvider();
            _elasticSearchService = (IElasticSearchService<T>)provider.GetService<IElasticSearchService<T>>();
        }
    }
}
