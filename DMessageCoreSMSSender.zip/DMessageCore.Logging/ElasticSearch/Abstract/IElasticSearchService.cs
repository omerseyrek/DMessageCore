﻿using DMessageCore.Logging.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging.ElasticSearch
{
    public interface IElasticSearchService<T> where T : class, IEntityModel,new()
    {
        public void CheckExistsAndInsertLog(T logModel);

        //istersek buradan da UI tarafına loglarımızı gösterebiliriz
       // public IReadOnlyCollection<T> SearchLoginLog(string guid ); 

    }
}
