﻿using DMessageCore.Logging.Models;
using Nest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging.ElasticSearch
{
    public class ElasticSearchService<T> : IElasticSearchService<T> where T : class, IEntityModel,new()
    {
        ElasticClientProvider _provider;
        ElasticClient _client;
        public ElasticSearchService(ElasticClientProvider provider,
            Microsoft.Extensions.Options.IOptions<ElasticConnectionSettings> elasticConfig)
        {
            _provider = provider;
            _client = _provider.ElasticClient;
            IndexName = elasticConfig.Value.ElasticSearchHostIndexName;
        }
        public string IndexName { get; set; }

        public void CheckExistsAndInsertLog(T logModel)
        {
            if (!_client.Indices.Exists(IndexName).Exists)
            {
                var newIndexName = IndexName + System.DateTime.Now.Ticks;

                var indexSettings = new IndexSettings();
                indexSettings.NumberOfReplicas = 1;
                indexSettings.NumberOfShards = 3;

                var response = _client.Indices.Create(newIndexName, index =>
                   index.Map<T>(m => m.AutoMap()
                          )
                  .InitializeUsing(new IndexState() { Settings = indexSettings })
                  .Aliases(a => a.Alias(IndexName)));

            }
            IndexResponse responseIndex = _client.Index<T>(logModel, idx => idx.Index(IndexName));
        }
    }
}
