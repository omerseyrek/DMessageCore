﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging.ElasticSearch
{
    public class ElasticConnectionSettings
    {
        public string ElasticSearchHost { get; set; }
        public string ElasticSearchHostIndexName { get; set; }
    }
}
