﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DMessageCore.Logging.Common
{
    public static class ProcessConstants
    {
        public static readonly string UpdateDefinitions = "Sender - Müşteri Parametresi Güncelleme";
        public static readonly string SendSMS = "Sender - SMS Gönderimi";
        public static readonly string SendSMSShot = "Sender -Shot SMS Gönderimi";
        public static readonly string SendEmail = "Sender - e-mail Gönderimi";
        public static readonly string SendNotification = "Sender - Notification Gönderimi";
        public static readonly string EMailTokenExchange = "Sender - e-mail Token Exchange";
        public static readonly string SMSTokenExchange = "Sender - SMS Token Exchange";
    }
}
