using Microsoft.Extensions.Configuration;
using System;
using System.Security.Claims;
using Xunit;

namespace DMessageCore.Sender.Tests
{
    public class TokenServiceTests
    {




    }
}
